// Analyse hors ligne d'une annonce, sans Discord : npx tsx carvanta/cli.ts annonce.txt [cote]
import { readFileSync } from "node:fs";
import { loadConfig } from "./config.ts";
import { alertEmbed, detailText } from "./embed.ts";
import { Carvanta } from "./service.ts";
import { Store } from "./store.ts";

const file = process.argv[2];
if (!file) { console.error("Usage : npx tsx carvanta/cli.ts annonce.txt [cote]"); process.exit(1); }
const app = new Carvanta(loadConfig(), new Store());
const a = app.analyseText(readFileSync(file, "utf8"), undefined, process.argv[3] ? Number(process.argv[3]) : undefined);
const e = alertEmbed(a);
console.log(`\n${e.title}\n${e.description}\n`);
for (const f of e.fields) console.log(`${f.name}\n  ${f.value.replace(/\n/g, "\n  ")}`);
console.log(`\n--- Détail ---\n${detailText(a)}\n`);
