// Chaîne complète : filtres → défauts → marché → rentabilité → score.
import type { Config } from "./config.ts";
import { estimateMarket } from "./market.ts";
import { norm } from "./parse.ts";
import { computeProfit } from "./profit.ts";
import { analyseRepairs } from "./repairs.ts";
import { scoreListing } from "./score.ts";
import type { Analysis, Listing, StoredListing } from "./types.ts";

export function checkFilters(l: Listing, f: Config["filters"]): string[] {
  const why: string[] = [];
  if (f.departments.length && l.department && !f.departments.includes(l.department)) why.push(`département ${l.department} hors zone`);
  if (f.makes.length && l.make && !f.makes.map(norm).includes(l.make)) why.push(`marque ${l.make} non suivie`);
  if (f.excludeMakes.length && l.make && f.excludeMakes.map(norm).includes(l.make)) why.push(`marque ${l.make} exclue`);
  if (f.models.length && l.model && !f.models.map(norm).some((m) => l.model!.startsWith(m))) why.push(`modèle ${l.model} non suivi`);
  if (f.yearMin && l.year && l.year < f.yearMin) why.push(`année ${l.year} < ${f.yearMin}`);
  if (f.yearMax && l.year && l.year > f.yearMax) why.push(`année ${l.year} > ${f.yearMax}`);
  if (f.kmMax && l.km && l.km > f.kmMax) why.push(`${l.km} km > ${f.kmMax}`);
  if (f.fuels.length && l.fuel && !f.fuels.includes(l.fuel)) why.push(`carburant ${l.fuel} non suivi`);
  if (f.gearboxes.length && l.gearbox && !f.gearboxes.includes(l.gearbox)) why.push(`boîte ${l.gearbox} non suivie`);
  if (f.requireCt && l.ct !== "ok") why.push("contrôle technique non confirmé");
  return why;
}

export function analyse(l: Listing, pool: StoredListing[], cfg: Config, opts: { userValue?: number; now?: Date } = {}): Analysis {
  const now = opts.now ?? new Date();
  const repairs = analyseRepairs(l.description);
  const market = estimateMarket(l, pool, cfg.market, opts.userValue, now);
  const profit = computeProfit(l, repairs, market, cfg.costs);
  const score = scoreListing(l, repairs, market, profit, cfg);
  const filterReasons = checkFilters(l, cfg.filters);
  return { listing: l, repairs, market, profit, score, analyzedAt: now.toISOString(), passesFilters: filterReasons.length === 0, filterReasons };
}
