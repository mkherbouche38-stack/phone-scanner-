// Types partagés de Carvanta Scanner

export type Fuel = "essence" | "diesel" | "hybride" | "electrique" | "gpl" | "autre";
export type Gearbox = "manuelle" | "automatique";
export type CtStatus = "ok" | "a_faire" | "contre_visite" | "inconnu";
export type Source = "email" | "manuel" | "import";

/** Annonce normalisée : uniquement ce qui est réellement connu (le reste est undefined). */
export interface Listing {
  id: string;                 // "lbc:123456789" ou "h:<empreinte>" si pas d'identifiant
  url?: string;
  source: Source;
  title: string;
  make?: string;              // marque normalisée (minuscules, sans accents)
  model?: string;             // modèle normalisé
  engine?: string;            // motorisation si connue (ex. "1.6 hdi")
  year?: number;
  km?: number;
  price?: number;
  location?: string;
  department?: string;        // "34", "2A"…
  description?: string;
  fuel?: Fuel;
  gearbox?: Gearbox;
  ct: CtStatus;
  seller?: "particulier" | "pro";
  publishedAt?: string;
  photos?: string[];
}

export type RepairLevel = "A" | "B" | "C";

export interface RepairItem {
  key: string;
  label: string;
  level: RepairLevel;
  low: number;
  high: number;
  parts: string;
  labour: string;
  diy: boolean;               // faisable par un amateur prudent
  safety: boolean;            // touche à la sécurité
  confidence: "faible" | "moyenne";
  evidence: string;           // extrait de l'annonce qui a déclenché la détection
}

export interface AdminIssue { key: string; label: string; evidence: string }

export interface RepairAnalysis {
  items: RepairItem[];
  admin: AdminIssue[];
  low: number;
  high: number;
  hasMajorRisk: boolean;      // au moins un niveau C mécanique / sécurité
  descriptionKnown: boolean;
}

export interface MarketEstimate {
  comparables: number;
  prudent?: number;           // 1er quartile des prix demandés comparables
  central?: number;           // médiane
  optimistic?: number;        // 3e quartile
  method: string;
  confidence: "aucune" | "faible" | "moyenne" | "bonne";
  date: string;
}

export interface Range { low: number; mid: number; high: number }

export interface ProfitResult {
  purchase: number;
  repairs: Range;
  transport: number;
  admin: number;              // carte grise + frais administratifs
  ct: number;
  cleaning: number;
  sellingFees: number;
  contingency: Range;
  total: Range;
  resale?: { prudent: number; central: number; optimistic: number };
  margin?: { prudent: number; central: number; optimistic: number };
  roi?: { prudent: number; central: number; optimistic: number };
  notes: string[];
}

export type Verdict =
  | "EXCELLENTE OPPORTUNITÉ À VÉRIFIER"
  | "OPPORTUNITÉ INTÉRESSANTE"
  | "À ANALYSER"
  | "RISQUE ÉLEVÉ"
  | "REJETÉE";

export interface ScoreFactor { label: string; points: number; max: number; why: string }

export interface ScoreResult {
  score: number;
  verdict: Verdict;
  factors: ScoreFactor[];
  risks: string[];
  missing: string[];
  reasons: string[];
  budgetCategory: "dans le budget" | "prix exceptionnellement bas" | "hors budget à fort potentiel" | "hors budget";
}

export interface Analysis {
  listing: Listing;
  repairs: RepairAnalysis;
  market: MarketEstimate;
  profit: ProfitResult;
  score: ScoreResult;
  analyzedAt: string;
  passesFilters: boolean;
  filterReasons: string[];
}

export interface StoredListing {
  listing: Listing;
  firstSeen: string;
  lastSeen: string;
  priceHistory: { date: string; price: number }[];
  status: "nouvelle" | "examinee" | "ecartee";
  favorite: boolean;
  alerted: boolean;
  lastAnalysis?: Analysis;
}
