// Tests du bot (sans réseau) : npx tsx --test carvanta/bot.test.ts
import assert from "node:assert/strict";
import { mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { test } from "node:test";
import { COMMANDS, fitEmbeds, setConfigValue } from "./bot.ts";
import { DEFAULT_CONFIG } from "./config.ts";
import { DiscordRest } from "./discord.ts";
import { alertEmbed } from "./embed.ts";
import { parseAdText } from "./parse.ts";
import { Carvanta } from "./service.ts";
import { Store } from "./store.ts";

const tmpStore = () => new Store(join(mkdtempSync(join(tmpdir(), "cvb-")), "db.json"));
const ad = (id: number, price: number, extra = "") => parseAdText(
  `Peugeot 207 1.4 essence\n${price} €\nSète 34200\nAnnée modèle : 2009\nKilométrage : 150 000 km\nEssence. Manuelle. CT OK. ${extra}`,
  { url: `https://www.leboncoin.fr/ad/voitures/${2_900_000_000 + id}`, source: "email" });

test("commandes slash conformes aux limites Discord", () => {
  for (const c of COMMANDS) {
    assert.match(c.name, /^[a-z0-9_-]{1,32}$/);
    assert.ok(c.description.length <= 100, c.name);
    for (const o of c.options ?? []) { assert.match(o.name, /^[a-z0-9_-]{1,32}$/); assert.ok(o.description.length <= 100, `${c.name}.${o.name}`); }
  }
  assert.ok(COMMANDS.length <= 100);
});

test("/config respecte le type de chaque réglage", () => {
  const c = structuredClone(DEFAULT_CONFIG);
  assert.equal(setConfigValue(c, "filters.kmMax", "200000"), "200000");
  assert.equal(c.filters.kmMax, 200000);
  setConfigValue(c, "filters.makes", "Peugeot, Renault");
  assert.deepEqual(c.filters.makes, ["Peugeot", "Renault"]);
  setConfigValue(c, "filters.requireCt", "oui");
  assert.equal(c.filters.requireCt, true);
  assert.throws(() => setConfigValue(c, "costs.registration", "beaucoup"), /numérique/);
  assert.throws(() => setConfigValue(c, "inconnu.cle", "1"), /inconnue/);
  assert.throws(() => setConfigValue(c, "budget", "1"), /inconnue/);
  assert.throws(() => setConfigValue(c, "opportunities.alertMinVerdict", "SUPER"), /valeurs possibles/);
});

test("ingestion : alerte une seule fois, puis réalerte seulement sur baisse de prix", () => {
  const store = tmpStore();
  const app = new Carvanta(structuredClone(DEFAULT_CONFIG), store, () => {});
  app.cfg.opportunities.alertMinVerdict = "À ANALYSER";
  // 8 comparables vers 3 500 € pour avoir un marché
  app.ingest([3200, 3300, 3400, 3500, 3600, 3700, 3800, 3900].map((p, i) => ad(i, p)));
  const r1 = app.ingest([ad(50, 1500)]);
  assert.equal(r1.created, 1);
  assert.equal(r1.alerts.length, 1);
  store.markAlerted(r1.alerts[0]);
  assert.equal(app.ingest([ad(50, 1500)]).alerts.length, 0, "pas de doublon d'alerte");
  const r3 = app.ingest([ad(50, 1300)]);
  assert.equal(r3.priceDrops, 1);
  assert.equal(r3.alerts.length, 1, "baisse de prix → nouvelle alerte");
  assert.equal(app.ingest([ad(50, 1400)]).alerts.length, 0, "hausse de prix → pas d'alerte");
});

test("ingestion : hors zone ou défaut grave → pas d'alerte, mais gardée en base", () => {
  const store = tmpStore();
  const app = new Carvanta(structuredClone(DEFAULT_CONFIG), store, () => {});
  app.cfg.opportunities.alertMinVerdict = "À ANALYSER";
  app.cfg.filters.departments = ["13"];
  assert.equal(app.ingest([ad(1, 1200)]).alerts.length, 0);
  app.cfg.filters.departments = [];
  const l = { ...ad(2, 1200), description: "Joint de culasse à refaire, chauffe beaucoup en ville, vendue en l'état." };
  assert.equal(app.ingest([l]).alerts.length, 0);
  assert.equal(store.all().length, 2);
});

test("une erreur de source n'arrête pas le bot et incrémente le compteur", async () => {
  const store = tmpStore();
  const app = new Carvanta(structuredClone(DEFAULT_CONFIG), store, () => {});
  await assert.rejects(app.pollEmail({ host: "127.0.0.1", port: 1, user: "x", password: "y", folder: "INBOX", from: "leboncoin" }));
  assert.equal(store.meta.consecutiveErrors, 1);
  assert.ok(store.meta.lastError);
});

test("plusieurs embeds tiennent dans la limite de 6 000 caractères", () => {
  const app = new Carvanta(structuredClone(DEFAULT_CONFIG), tmpStore(), () => {});
  const a = app.analyseText("Renault Clio 3 1.5 dCi\n1 500 €\nSète 34200\nKilométrage 180 000 km\nAnnée 2008\n" + "Embrayage qui patine. ".repeat(40));
  const out = fitEmbeds(Array(10).fill(alertEmbed(a)));
  const size = JSON.stringify(out.map((e) => [e.title, e.description, e.footer?.text, e.fields.map((f) => f.name + f.value)])).length;
  assert.ok(out.length >= 1 && out.length < 10);
  assert.ok(size < 7000);
});

test("REST Discord : nouvel essai après un 429, sans exposer le token", async () => {
  const calls: { url: string; auth: string }[] = [];
  const realFetch = globalThis.fetch;
  globalThis.fetch = (async (url: string, init: RequestInit) => {
    calls.push({ url, auth: String((init.headers as Record<string, string>).authorization) });
    if (calls.length === 1) return new Response(JSON.stringify({ retry_after: 0.01 }), { status: 429 });
    if (calls.length === 2) return new Response(JSON.stringify({ id: "1" }), { status: 200 });
    return new Response("nope", { status: 403 });
  }) as typeof fetch;
  try {
    const rest = new DiscordRest("SECRET_TOKEN_123", "42");
    assert.deepEqual(await rest.sendMessage("777", { content: "x" }), { id: "1" });
    assert.equal(calls.length, 2);
    assert.equal(calls[0].auth, "Bot SECRET_TOKEN_123");
    await assert.rejects(rest.sendMessage("777", {}), (e: Error) => !e.message.includes("SECRET_TOKEN_123") && /403/.test(e.message));
  } finally { globalThis.fetch = realFetch; }
});
