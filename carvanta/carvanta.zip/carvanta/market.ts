// Estimation du prix de marché à partir de comparables OBSERVÉS (annonces déjà collectées).
// Ce sont des prix DEMANDÉS, pas des prix de vente : le prix « prudent » prend le 1er quartile.
import type { Config } from "./config.ts";
import type { Listing, MarketEstimate, StoredListing } from "./types.ts";

export function quantile(sorted: number[], q: number): number {
  if (!sorted.length) return NaN;
  const pos = (sorted.length - 1) * q;
  const lo = Math.floor(pos);
  const hi = Math.ceil(pos);
  return Math.round(sorted[lo] + (sorted[hi] - sorted[lo]) * (pos - lo));
}

export const median = (values: number[]) => quantile([...values].sort((a, b) => a - b), 0.5);

export function findComparables(target: Listing, pool: StoredListing[], cfg: Config["market"], now = Date.now()): Listing[] {
  if (!target.make || !target.model) return [];
  const maxAge = cfg.maxAgeDays * 86_400_000;
  return pool
    .filter((s) => {
      const l = s.listing;
      if (l.id === target.id || !l.price) return false;
      if (now - Date.parse(s.lastSeen) > maxAge) return false;
      if (l.make !== target.make || l.model !== target.model) return false;
      if (target.fuel && l.fuel && target.fuel !== l.fuel) return false;
      if (target.gearbox && l.gearbox && target.gearbox !== l.gearbox) return false;
      if (target.year && (!l.year || Math.abs(l.year - target.year) > cfg.yearTolerance)) return false;
      if (target.km && (!l.km || Math.abs(l.km - target.km) > cfg.kmTolerance)) return false;
      // on écarte les épaves et ventes problématiques des comparables
      if (s.lastAnalysis?.repairs.hasMajorRisk || s.lastAnalysis?.repairs.admin.length) return false;
      return true;
    })
    .map((s) => s.listing);
}

/** Retire les prix aberrants (hors 0,4×–2,5× la médiane). */
function dropOutliers(prices: number[]): number[] {
  const m = median(prices);
  return prices.filter((p) => p >= m * 0.4 && p <= m * 2.5);
}

export function estimateMarket(
  target: Listing, pool: StoredListing[], cfg: Config["market"],
  userValue?: number, now = new Date(),
): MarketEstimate {
  const date = now.toISOString();
  if (userValue && userValue > 0) {
    return {
      comparables: 0, prudent: Math.round(userValue * 0.9), central: Math.round(userValue), optimistic: Math.round(userValue * 1.05),
      method: "Cote fournie par l'utilisateur (prudent −10 %, optimiste +5 %)", confidence: "moyenne", date,
    };
  }
  const comps = findComparables(target, pool, cfg, now.getTime());
  const prices = dropOutliers(comps.map((c) => c.price!)).sort((a, b) => a - b);
  if (prices.length < cfg.minComparables) {
    return {
      comparables: prices.length, method: `Comparables insuffisants (${prices.length} < ${cfg.minComparables} requis)`,
      confidence: prices.length ? "faible" : "aucune", date,
      ...(prices.length ? { central: median(prices) } : {}),
    };
  }
  return {
    comparables: prices.length,
    prudent: quantile(prices, 0.25), central: quantile(prices, 0.5), optimistic: quantile(prices, 0.75),
    method: `Quartiles de ${prices.length} prix demandés comparables (même marque/modèle, ±${cfg.yearTolerance} ans, ±${Math.round(cfg.kmTolerance / 1000)} 000 km, ${cfg.maxAgeDays} j)`,
    confidence: prices.length >= 8 ? "bonne" : "moyenne",
    date,
  };
}
