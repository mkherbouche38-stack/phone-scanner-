// Chargement et sauvegarde de la configuration (config.json) — modifiable sans toucher au code.
import { existsSync, readFileSync, renameSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import type { Fuel, Gearbox, Verdict } from "./types.ts";

export const HERE = dirname(fileURLToPath(import.meta.url));
export const CONFIG_PATH = process.env.CARVANTA_CONFIG ?? join(HERE, "config.json");

export interface Config {
  budget: { min: number; max: number };
  opportunities: { exceptionalDiscountPct: number; outOfBudgetMinPrudentMargin: number; minCentralMargin: number; alertMinVerdict: Verdict };
  filters: {
    departments: string[]; makes: string[]; excludeMakes: string[]; models: string[];
    yearMin: number | null; yearMax: number | null; kmMax: number | null;
    fuels: Fuel[]; gearboxes: Gearbox[]; requireCt: boolean;
  };
  costs: {
    transport: number; registration: number; adminFees: number; ctIfMissing: number;
    cleaning: number; sellingFees: number; contingencyPct: number; contingencyMin: number;
  };
  market: { yearTolerance: number; kmTolerance: number; maxAgeDays: number; minComparables: number };
  polling: { everyMinutes: number; maxEmailsPerPoll: number };
  discord: { alertChannelId: string; adminChannelId: string };
}

export const DEFAULT_CONFIG: Config = {
  budget: { min: 700, max: 2000 },
  opportunities: { exceptionalDiscountPct: 40, outOfBudgetMinPrudentMargin: 1200, minCentralMargin: 400, alertMinVerdict: "OPPORTUNITÉ INTÉRESSANTE" },
  filters: {
    departments: [], makes: [], excludeMakes: [], models: [],
    yearMin: null, yearMax: null, kmMax: null, fuels: [], gearboxes: [], requireCt: false,
  },
  costs: { transport: 60, registration: 250, adminFees: 15, ctIfMissing: 80, cleaning: 40, sellingFees: 0, contingencyPct: 10, contingencyMin: 150 },
  market: { yearTolerance: 2, kmTolerance: 40000, maxAgeDays: 120, minComparables: 3 },
  polling: { everyMinutes: 5, maxEmailsPerPoll: 30 },
  discord: { alertChannelId: "", adminChannelId: "" },
};

const isObj = (v: unknown): v is Record<string, unknown> => typeof v === "object" && v !== null && !Array.isArray(v);

/** Fusion profonde : les clés absentes du fichier gardent leur valeur par défaut. */
function merge<T>(base: T, over: unknown): T {
  if (!isObj(base) || !isObj(over)) return (over === undefined ? base : (over as T));
  const out: Record<string, unknown> = { ...base };
  for (const [k, v] of Object.entries(over)) out[k] = k in out ? merge((base as Record<string, unknown>)[k], v) : v;
  return out as T;
}

export function validateConfig(c: Config): string[] {
  const err: string[] = [];
  if (!(c.budget.min >= 0 && c.budget.max > c.budget.min)) err.push("budget : min doit être ≥ 0 et max > min");
  if (c.costs.contingencyPct < 0 || c.costs.contingencyPct > 100) err.push("costs.contingencyPct doit être entre 0 et 100");
  if (c.polling.everyMinutes < 1) err.push("polling.everyMinutes doit être ≥ 1");
  if (c.market.minComparables < 1) err.push("market.minComparables doit être ≥ 1");
  return err;
}

export function loadConfig(path = CONFIG_PATH): Config {
  const raw = existsSync(path) ? JSON.parse(readFileSync(path, "utf8")) : {};
  const c = merge(DEFAULT_CONFIG, raw);
  const err = validateConfig(c);
  if (err.length) throw new Error(`config.json invalide :\n- ${err.join("\n- ")}`);
  return c;
}

export function saveConfig(c: Config, path = CONFIG_PATH) {
  const err = validateConfig(c);
  if (err.length) throw new Error(err.join(" ; "));
  const tmp = `${path}.tmp`;
  writeFileSync(tmp, JSON.stringify(c, null, 2) + "\n");
  renameSync(tmp, path);
}
