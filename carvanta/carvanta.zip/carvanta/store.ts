// Stockage local (fichier JSON) : historique, anti-doublons, changements de prix, statut, favoris.
import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { HERE } from "./config.ts";
import { fingerprint } from "./parse.ts";
import type { Analysis, Listing, StoredListing } from "./types.ts";

export interface Meta {
  imapLastUid?: number;
  lastPollAt?: string;
  lastPollOk?: string;
  consecutiveErrors: number;
  lastError?: string;
  adminAlerted: boolean;
  startedAt?: string;
}
export interface AlertLog { id: string; date: string; verdict: string; score: number; price?: number }
interface DbShape { version: 1; listings: Record<string, StoredListing>; alerts: AlertLog[]; meta: Meta }

export type UpsertResult = { stored: StoredListing; isNew: boolean; priceChange?: { from: number; to: number }; duplicateOf?: string };

export class Store {
  private db: DbShape;
  constructor(readonly path = process.env.CARVANTA_DB ?? join(HERE, "data", "carvanta-db.json")) {
    this.db = existsSync(path)
      ? JSON.parse(readFileSync(path, "utf8"))
      : { version: 1, listings: {}, alerts: [], meta: { consecutiveErrors: 0, adminAlerted: false } };
  }

  get meta() { return this.db.meta; }
  all(): StoredListing[] { return Object.values(this.db.listings); }
  get(id: string): StoredListing | undefined { return this.db.listings[id] ?? this.all().find((s) => s.listing.id.endsWith(id)); }
  alerts(n = 10): AlertLog[] { return this.db.alerts.slice(-n).reverse(); }

  /** Doublon de secours : même empreinte (marque, modèle, année, km, prix, lieu) sous un autre identifiant. */
  private findDuplicate(l: Listing): StoredListing | undefined {
    if (!l.make) return undefined;
    const fp = fingerprint(l);
    // deux identifiants Leboncoin différents = deux annonces distinctes ; l'empreinte ne sert que si l'un n'en a pas
    return this.all().find((s) => s.listing.id !== l.id && !(s.listing.id.startsWith("lbc:") && l.id.startsWith("lbc:")) && fingerprint(s.listing) === fp);
  }

  upsert(l: Listing, now = new Date().toISOString()): UpsertResult {
    const existing = this.db.listings[l.id];
    if (!existing) {
      const dup = this.findDuplicate(l);
      if (dup) { dup.lastSeen = now; return { stored: dup, isNew: false, duplicateOf: dup.listing.id }; }
      const stored: StoredListing = {
        listing: l, firstSeen: now, lastSeen: now, priceHistory: l.price ? [{ date: now, price: l.price }] : [],
        status: "nouvelle", favorite: false, alerted: false,
      };
      this.db.listings[l.id] = stored;
      return { stored, isNew: true };
    }
    existing.lastSeen = now;
    // on complète sans écraser une info connue par une info absente (ex. alerte e-mail sans description)
    const merged = { ...existing.listing } as Record<string, unknown>;
    for (const [k, v] of Object.entries(l)) if (v !== undefined && v !== "" && !(k === "ct" && v === "inconnu")) merged[k] = v;
    existing.listing = merged as unknown as Listing;
    const last = existing.priceHistory.at(-1)?.price;
    let priceChange: UpsertResult["priceChange"];
    if (l.price && l.price !== last) {
      existing.priceHistory.push({ date: now, price: l.price });
      if (last) priceChange = { from: last, to: l.price };
    }
    return { stored: existing, isNew: false, priceChange };
  }

  setAnalysis(id: string, a: Analysis) { const s = this.db.listings[id]; if (s) s.lastAnalysis = a; }
  markAlerted(a: Analysis) {
    const s = this.db.listings[a.listing.id];
    if (s) s.alerted = true;
    this.db.alerts.push({ id: a.listing.id, date: new Date().toISOString(), verdict: a.score.verdict, score: a.score.score, price: a.listing.price });
    if (this.db.alerts.length > 2000) this.db.alerts.splice(0, this.db.alerts.length - 2000);
  }
  setStatus(id: string, status: StoredListing["status"]) { const s = this.get(id); if (s) s.status = status; return s; }
  toggleFavorite(id: string) { const s = this.get(id); if (s) s.favorite = !s.favorite; return s; }

  best(n = 5): StoredListing[] {
    return this.all()
      .filter((s) => s.lastAnalysis && s.status !== "ecartee" && s.lastAnalysis.passesFilters)
      .sort((a, b) => b.lastAnalysis!.score.score - a.lastAnalysis!.score.score)
      .slice(0, n);
  }

  save() {
    mkdirSync(dirname(this.path), { recursive: true });
    const tmp = `${this.path}.tmp`;
    writeFileSync(tmp, JSON.stringify(this.db));
    renameSync(tmp, this.path);
  }
}
