// Embeds Discord Carvanta (noir / blanc / violet), lisibles sur mobile, + boutons d'action.
import type { Analysis, Verdict } from "./types.ts";

export interface Embed {
  title?: string; url?: string; description?: string; color: number;
  fields: { name: string; value: string; inline?: boolean }[];
  footer?: { text: string }; timestamp?: string;
}

const VIOLET = 0x7c3aed, VIOLET_CLAIR = 0xa78bfa, BLANC = 0xf4f4f5, NOIR = 0x18181b;
const COLORS: Record<Verdict, number> = {
  "EXCELLENTE OPPORTUNITÉ À VÉRIFIER": VIOLET, "OPPORTUNITÉ INTÉRESSANTE": VIOLET_CLAIR,
  "À ANALYSER": BLANC, "RISQUE ÉLEVÉ": NOIR, "REJETÉE": NOIR,
};
const BADGE: Record<Verdict, string> = {
  "EXCELLENTE OPPORTUNITÉ À VÉRIFIER": "🟣", "OPPORTUNITÉ INTÉRESSANTE": "🟪", "À ANALYSER": "⚪", "RISQUE ÉLEVÉ": "⚫", "REJETÉE": "✖️",
};

export const eur = (n?: number) => (n === undefined || Number.isNaN(n) ? "—" : `${Math.round(n).toLocaleString("fr-FR").replace(/ /g, " ")} €`);
const pct = (n?: number) => (n === undefined ? "—" : `${n.toLocaleString("fr-FR")} %`);
const cap = (s: string, n: number) => (s.length > n ? s.slice(0, n - 1) + "…" : s);
const title = (s: string) => s.replace(/\b\w/g, (c) => c.toUpperCase());

function headline(a: Analysis): string {
  const l = a.listing;
  const car = [l.make && title(l.make), l.model && title(l.model), l.engine].filter(Boolean).join(" ") || l.title;
  return cap([car, l.year, l.km && `${eur(l.km).replace(" €", "")} km`].filter(Boolean).join(" · "), 250);
}

export function alertEmbed(a: Analysis): Embed {
  const { listing: l, market: m, profit: p, score: s, repairs: r } = a;
  const defects = r.descriptionKnown
    ? (r.items.length ? r.items.map((i) => `${i.level === "A" ? "🟢" : i.level === "B" ? "🟠" : "🔴"} ${i.label} : ${eur(i.low)}–${eur(i.high)}${i.diy ? " (amateur)" : " (pro)"}`).join("\n") : "Aucun défaut déclaré")
    : "Inconnus (alerte sans description) → /analyse avec le texte complet";
  const fields: Embed["fields"] = [
    { name: "💶 Prix demandé", value: `**${eur(l.price)}**\n${s.budgetCategory}`, inline: true },
    { name: "📊 Marché", value: m.central ? `${eur(m.central)}\n${m.comparables} comparable(s) · confiance ${m.confidence}` : `non estimé\n${m.comparables} comparable(s)`, inline: true },
    { name: "🏁 Score", value: `**${s.score}/100**`, inline: true },
    { name: "🔧 Défauts signalés · réparations", value: cap(defects, 1024) },
    { name: "🧮 Coût total estimé", value: `${eur(p.total.low)} – ${eur(p.total.high)}\n(réparations ${eur(p.repairs.low)}–${eur(p.repairs.high)})`, inline: true },
    { name: "🏷️ Revente prudent / central / optimiste", value: p.resale ? `${eur(p.resale.prudent)} / ${eur(p.resale.central)} / ${eur(p.resale.optimistic)}` : "non estimée", inline: true },
    { name: "💰 Marge estimée (rendement)", value: p.margin
      ? `prudent ${eur(p.margin.prudent)} (${pct(p.roi!.prudent)})\ncentral ${eur(p.margin.central)} (${pct(p.roi!.central)})\noptimiste ${eur(p.margin.optimistic)} (${pct(p.roi!.optimistic)})`
      : "non calculable sans prix de revente" },
  ];
  if (s.risks.length) fields.push({ name: "⚠️ Risques", value: cap(s.risks.join("\n"), 1024) });
  if (s.missing.length) fields.push({ name: "❔ Infos manquantes", value: cap(s.missing.join(", "), 1024) });
  if (s.reasons.length) fields.push({ name: "🧭 Pourquoi", value: cap(s.reasons.join("\n"), 1024) });
  if (!a.passesFilters) fields.push({ name: "🔎 Hors filtres", value: cap(a.filterReasons.join(", "), 1024) });
  const where = [l.location, l.seller].filter(Boolean).join(" · ");
  return {
    title: `${BADGE[s.verdict]} ${s.verdict}`,
    url: l.url,
    description: cap(`**${headline(a)}**${where ? `\n📍 ${where}` : ""}${l.ct !== "inconnu" ? ` · CT : ${l.ct.replace("_", " ")}` : ""}`, 4000),
    color: COLORS[s.verdict],
    fields,
    footer: { text: cap(`Carvanta · ${l.id} · détectée le ${new Date(a.analyzedAt).toLocaleString("fr-FR", { timeZone: "Europe/Paris" })} · estimation, pas une garantie`, 2048) },
    timestamp: a.analyzedAt,
  };
}

/** Boutons : lien vers l'annonce + détail + examinée + favori. */
export function alertButtons(a: Analysis) {
  const id = a.listing.id;
  const buttons: Record<string, unknown>[] = [];
  if (a.listing.url) buttons.push({ type: 2, style: 5, label: "Voir l'annonce", url: a.listing.url });
  buttons.push(
    { type: 2, style: 2, label: "Analyse détaillée", custom_id: `cv:detail:${id}` },
    { type: 2, style: 3, label: "Examinée", custom_id: `cv:seen:${id}` },
    { type: 2, style: 1, label: "★ Favori", custom_id: `cv:fav:${id}` },
  );
  return [{ type: 1, components: buttons }];
}

/** Analyse détaillée en texte (message éphémère, ≤ 2000 caractères). */
export function detailText(a: Analysis): string {
  const { profit: p, market: m, score: s, repairs: r } = a;
  const lines = [
    `**${headline(a)}** — ${a.listing.id}`,
    `**Score ${s.score}/100 · ${s.verdict}**`,
    ...s.factors.map((f) => `• ${f.label} : ${f.points}/${f.max} — ${f.why}`),
    "",
    `**Marché** : ${m.method} (${new Date(m.date).toLocaleDateString("fr-FR")})`,
    `**Coûts** : achat ${eur(p.purchase)} · réparations ${eur(p.repairs.low)}–${eur(p.repairs.high)} · transport ${eur(p.transport)} · carte grise/frais ${eur(p.admin)} · CT ${eur(p.ct)} · nettoyage ${eur(p.cleaning)} · frais revente ${eur(p.sellingFees)} · imprévus ${eur(p.contingency.low)}–${eur(p.contingency.high)}`,
    ...r.items.map((i) => `🔧 ${i.label} [${i.level}] ${eur(i.low)}–${eur(i.high)} · pièces : ${i.parts} · MO : ${i.labour} · confiance ${i.confidence} · « ${i.evidence} »`),
    ...r.admin.map((x) => `⛔ ${x.label} · « ${x.evidence} »`),
    ...p.notes.map((n) => `ℹ️ ${n}`),
  ];
  return cap(lines.join("\n"), 2000);
}
