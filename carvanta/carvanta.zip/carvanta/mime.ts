// Décodage minimal des e-mails (RFC 5322 / MIME) sans dépendance : en-têtes encodés, multipart,
// quoted-printable, base64, charsets utf-8 / iso-8859-1 / windows-1252.

export interface Mail { subject: string; from: string; date?: string; text: string; html: string }

function decodeBytes(buf: Buffer, charset = "utf-8"): string {
  const cs = charset.toLowerCase().replace(/["']/g, "");
  try { return new TextDecoder(cs === "latin1" ? "iso-8859-1" : cs).decode(buf); } catch { return buf.toString("utf8"); }
}

function qpToBuffer(s: string, header = false): Buffer {
  const src = header ? s.replace(/_/g, " ") : s.replace(/=\r?\n/g, "");
  const bytes: number[] = [];
  for (let i = 0; i < src.length; i++) {
    const c = src[i];
    if (c === "=" && /^[0-9A-F]{2}$/i.test(src.slice(i + 1, i + 3))) { bytes.push(parseInt(src.slice(i + 1, i + 3), 16)); i += 2; }
    else bytes.push(c.charCodeAt(0) & 0xff);
  }
  return Buffer.from(bytes);
}

export function decodeHeader(v: string): string {
  return v.replace(/\?=\s+=\?/g, "?==?").replace(/=\?([^?]+)\?([QBqb])\?([^?]*)\?=/g, (_, cs, enc, data) =>
    decodeBytes(enc.toUpperCase() === "B" ? Buffer.from(data, "base64") : qpToBuffer(data, true), cs));
}

function splitHeadersBody(raw: string): { headers: Record<string, string>; body: string } {
  const i = raw.search(/\r?\n\r?\n/);
  const head = i < 0 ? raw : raw.slice(0, i);
  const body = i < 0 ? "" : raw.slice(i).replace(/^\r?\n\r?\n/, "");
  const headers: Record<string, string> = {};
  for (const line of head.replace(/\r?\n[ \t]+/g, " ").split(/\r?\n/)) {
    const k = line.indexOf(":");
    if (k > 0) headers[line.slice(0, k).trim().toLowerCase()] = line.slice(k + 1).trim();
  }
  return { headers, body };
}

const param = (h: string | undefined, name: string) => h?.match(new RegExp(`${name}\\s*=\\s*"?([^";]+)"?`, "i"))?.[1];

function decodePart(headers: Record<string, string>, body: string): string {
  const enc = (headers["content-transfer-encoding"] ?? "").toLowerCase();
  const cs = param(headers["content-type"], "charset") ?? "utf-8";
  if (enc === "base64") return decodeBytes(Buffer.from(body.replace(/\s+/g, ""), "base64"), cs);
  if (enc === "quoted-printable") return decodeBytes(qpToBuffer(body), cs);
  return decodeBytes(Buffer.from(body, "binary"), cs);
}

function walk(raw: string, out: { text: string[]; html: string[] }, depth = 0) {
  const { headers, body } = splitHeadersBody(raw);
  const ct = (headers["content-type"] ?? "text/plain").toLowerCase();
  if (ct.startsWith("multipart/") && depth < 6) {
    const b = param(headers["content-type"], "boundary");
    if (!b) return;
    for (const part of body.split(new RegExp(`\\r?\\n?--${b.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}(?:--)?\\r?\\n?`))) {
      if (part.trim()) walk(part, out, depth + 1);
    }
    return;
  }
  if (ct.startsWith("text/html")) out.html.push(decodePart(headers, body));
  else if (ct.startsWith("text/plain")) out.text.push(decodePart(headers, body));
}

/** raw : e-mail complet. Les octets non ASCII doivent être fournis en « binary » (latin1) pour un décodage fidèle. */
export function decodeMime(raw: string): Mail {
  const { headers } = splitHeadersBody(raw);
  const out = { text: [] as string[], html: [] as string[] };
  walk(raw, out);
  return {
    subject: decodeHeader(headers["subject"] ?? ""),
    from: decodeHeader(headers["from"] ?? ""),
    date: headers["date"],
    text: out.text.join("\n"),
    html: out.html.join("\n"),
  };
}
