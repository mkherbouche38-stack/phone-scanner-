// Calcul de rentabilité : coût total = achat + réparations + transport + frais + provision.
// Marge = revente − coût total. Rendement = marge / coût total × 100. Avant impôts et charges.
import type { Config } from "./config.ts";
import type { Listing, MarketEstimate, ProfitResult, Range, RepairAnalysis } from "./types.ts";

const r = (n: number) => Math.round(n);
const mid = (a: number, b: number) => (a + b) / 2;

export function computeProfit(l: Listing, repairs: RepairAnalysis, market: MarketEstimate, costs: Config["costs"]): ProfitResult {
  const notes: string[] = [];
  const purchase = l.price ?? 0;
  if (!l.price) notes.push("Prix d'achat inconnu : calcul impossible tant qu'il manque.");

  // Réparations : si la description est inconnue, on ne peut pas savoir → fourchette élargie
  let repLow = repairs.low;
  let repHigh = repairs.high;
  if (!repairs.descriptionKnown) {
    repHigh += 500;
    notes.push("Description non lue : +500 € ajoutés au haut de fourchette réparations (défauts non déclarés possibles).");
  } else if (repairs.items.some((i) => i.level !== "A")) {
    repHigh = r(repHigh * 1.25);
    notes.push("Travaux à diagnostiquer : haut de fourchette majoré de 25 %.");
  }
  const repairsR: Range = { low: r(repLow), mid: r(mid(repLow, repHigh)), high: r(repHigh) };

  const ct = l.ct === "ok" ? 0 : costs.ctIfMissing;
  if (l.ct === "inconnu") notes.push("Contrôle technique non mentionné : coût d'un CT inclus par prudence.");
  const admin = costs.registration + costs.adminFees;
  const fixed = costs.transport + admin + ct + costs.cleaning + costs.sellingFees;

  const prov = (rep: number) => Math.max(costs.contingencyMin, (purchase + rep) * costs.contingencyPct / 100);
  const contingency: Range = { low: r(prov(repairsR.low)), mid: r(prov(repairsR.mid)), high: r(prov(repairsR.high)) };
  const total: Range = {
    low: r(purchase + repairsR.low + fixed + contingency.low),
    mid: r(purchase + repairsR.mid + fixed + contingency.mid),
    high: r(purchase + repairsR.high + fixed + contingency.high),
  };

  const res: ProfitResult = {
    purchase, repairs: repairsR, transport: costs.transport, admin, ct, cleaning: costs.cleaning,
    sellingFees: costs.sellingFees, contingency, total, notes,
  };

  if (market.prudent && market.central && market.optimistic && l.price) {
    res.resale = { prudent: market.prudent, central: market.central, optimistic: market.optimistic };
    // scénario prudent = revente basse ET coûts hauts ; optimiste = revente haute ET coûts bas
    res.margin = {
      prudent: r(market.prudent - total.high),
      central: r(market.central - total.mid),
      optimistic: r(market.optimistic - total.low),
    };
    const roi = (m: number, c: number) => (c > 0 ? Math.round((m / c) * 1000) / 10 : 0);
    res.roi = { prudent: roi(res.margin.prudent, total.high), central: roi(res.margin.central, total.mid), optimistic: roi(res.margin.optimistic, total.low) };
  } else {
    notes.push("Prix de revente non estimé (comparables insuffisants) : aucune marge calculée.");
  }
  notes.push("Impôts, cotisations et statut (particulier / micro-entreprise / marchand VO) non inclus : ils dépendent de ta situation.");
  return res;
}
