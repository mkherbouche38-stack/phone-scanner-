// Client IMAP minimal (lecture seule, TLS) pour récupérer les alertes e-mail Leboncoin de TA boîte mail.
// Aucune dépendance. Les messages ne sont jamais modifiés (EXAMINE + BODY.PEEK).
import { connect, type TLSSocket } from "node:tls";
import { decodeMime, type Mail } from "./mime.ts";

export interface ImapConfig { host: string; port: number; user: string; password: string; folder: string; from: string }

class ImapSession {
  private buf = Buffer.alloc(0);
  private waiters: (() => void)[] = [];
  private closed = false;
  private n = 0;
  constructor(private sock: TLSSocket) {
    sock.on("data", (d: Buffer) => { this.buf = Buffer.concat([this.buf, d]); this.wake(); });
    sock.on("close", () => { this.closed = true; this.wake(); });
    sock.on("error", () => { this.closed = true; this.wake(); });
  }
  private wake() { const w = this.waiters; this.waiters = []; w.forEach((f) => f()); }
  private async waitData(timeoutMs: number) {
    if (this.closed) throw new Error("connexion IMAP fermée");
    await new Promise<void>((res, rej) => {
      const t = setTimeout(() => rej(new Error("délai IMAP dépassé")), timeoutMs);
      this.waiters.push(() => { clearTimeout(t); res(); });
    });
  }
  private async readLine(timeoutMs = 30_000): Promise<string> {
    for (;;) {
      const i = this.buf.indexOf("\r\n");
      if (i >= 0) { const line = this.buf.subarray(0, i).toString("latin1"); this.buf = this.buf.subarray(i + 2); return line; }
      await this.waitData(timeoutMs);
    }
  }
  private async readBytes(n: number, timeoutMs = 60_000): Promise<Buffer> {
    while (this.buf.length < n) await this.waitData(timeoutMs);
    const out = this.buf.subarray(0, n); this.buf = this.buf.subarray(n); return out;
  }
  async greeting() { const l = await this.readLine(); if (!/^\* (OK|PREAUTH)/i.test(l)) throw new Error(`IMAP : accueil inattendu`); }

  /** Envoie une commande et renvoie les lignes de réponse + les littéraux {n} (corps des messages). */
  async cmd(command: string, timeoutMs = 60_000): Promise<{ lines: string[]; literals: Buffer[] }> {
    const tag = `C${++this.n}`;
    this.sock.write(`${tag} ${command}\r\n`);
    const lines: string[] = [];
    const literals: Buffer[] = [];
    for (;;) {
      const line = await this.readLine(timeoutMs);
      const lit = line.match(/\{(\d+)\}$/);
      if (lit) { literals.push(await this.readBytes(Number(lit[1]), timeoutMs)); lines.push(line); continue; }
      if (line.startsWith(`${tag} `)) {
        if (!/^\S+ OK/i.test(line)) throw new Error(`IMAP ${command.split(" ")[0]} refusé : ${line.slice(tag.length + 1, tag.length + 120)}`);
        return { lines, literals };
      }
      lines.push(line);
    }
  }
  end() { try { this.sock.end(); } catch { /* ignore */ } }
}

const q = (s: string) => `"${s.replace(/\\/g, "\\\\").replace(/"/g, '\\"')}"`;
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const imapDate = (d: Date) => `${d.getUTCDate()}-${MONTHS[d.getUTCMonth()]}-${d.getUTCFullYear()}`;

export interface FetchedMail { uid: number; mail: Mail }

/** Récupère les nouveaux e-mails d'alerte depuis lastUid (ou des 3 derniers jours au premier lancement). */
export async function fetchAlertMails(cfg: ImapConfig, lastUid: number | undefined, max: number): Promise<{ mails: FetchedMail[]; lastUid?: number }> {
  const sock = connect({ host: cfg.host, port: cfg.port, servername: cfg.host });
  await new Promise<void>((res, rej) => { sock.once("secureConnect", () => res()); sock.once("error", rej); });
  const s = new ImapSession(sock);
  try {
    await s.greeting();
    await s.cmd(`LOGIN ${q(cfg.user)} ${q(cfg.password)}`);
    await s.cmd(`EXAMINE ${q(cfg.folder)}`);
    const crit = lastUid ? `UID ${lastUid + 1}:*` : `SINCE ${imapDate(new Date(Date.now() - 3 * 86_400_000))}`;
    const res = await s.cmd(`UID SEARCH ${crit} FROM ${q(cfg.from)}`);
    const uids = res.lines.filter((l) => l.startsWith("* SEARCH")).flatMap((l) => l.slice(8).trim().split(/\s+/)).map(Number)
      .filter((u) => u > 0 && (!lastUid || u > lastUid)).sort((a, b) => a - b).slice(-max);
    const mails: FetchedMail[] = [];
    for (const uid of uids) {
      const f = await s.cmd(`UID FETCH ${uid} BODY.PEEK[]`, 120_000);
      if (f.literals[0]) mails.push({ uid, mail: decodeMime(f.literals[0].toString("latin1")) });
    }
    try { await s.cmd("LOGOUT", 5_000); } catch { /* ignore */ }
    return { mails, lastUid: uids.length ? Math.max(lastUid ?? 0, ...uids) : lastUid };
  } finally {
    s.end();
  }
}
