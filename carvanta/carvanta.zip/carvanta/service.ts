// Logique métier indépendante de Discord : ingestion, analyse, décision d'alerte, collecte e-mail.
import { analyse } from "./analyze.ts";
import type { Config } from "./config.ts";
import { fetchAlertMails, type ImapConfig } from "./imap.ts";
import { parseAdText, parseAlertEmail } from "./parse.ts";
import { VERDICT_RANK } from "./score.ts";
import type { Store } from "./store.ts";
import type { Analysis, Listing } from "./types.ts";

export interface IngestReport { seen: number; created: number; duplicates: number; priceDrops: number; alerts: Analysis[] }

export class Carvanta {
  constructor(public cfg: Config, readonly store: Store, private log: (m: string) => void = console.log) {}

  /** Faut-il envoyer une alerte ? Nouvelle annonce (ou baisse de prix) dans les filtres et au-dessus du seuil. */
  shouldAlert(a: Analysis, isNew: boolean, priceDrop: boolean, alreadyAlerted: boolean): boolean {
    if (!a.passesFilters) return false;
    if (VERDICT_RANK[a.score.verdict] < VERDICT_RANK[this.cfg.opportunities.alertMinVerdict]) return false;
    return (isNew && !alreadyAlerted) || priceDrop;
  }

  ingest(listings: Listing[], now = new Date()): IngestReport {
    const rep: IngestReport = { seen: listings.length, created: 0, duplicates: 0, priceDrops: 0, alerts: [] };
    for (const l of listings) {
      const up = this.store.upsert(l, now.toISOString());
      if (up.duplicateOf) { rep.duplicates++; continue; }
      if (up.isNew) rep.created++;
      const drop = Boolean(up.priceChange && up.priceChange.to < up.priceChange.from);
      if (drop) rep.priceDrops++;
      const a = analyse(up.stored.listing, this.store.all(), this.cfg, { now });
      this.store.setAnalysis(up.stored.listing.id, a);
      if (this.shouldAlert(a, up.isNew, drop, up.stored.alerted)) rep.alerts.push(a);
    }
    return rep;
  }

  /** Analyse d'une annonce collée par l'utilisateur (commande /analyse). */
  analyseText(text: string, url?: string, userValue?: number, now = new Date()): Analysis {
    const l = parseAdText(text, { url, source: "manuel" });
    const up = this.store.upsert(l, now.toISOString());
    const target = up.stored.listing;
    const a = analyse(target, this.store.all(), this.cfg, { userValue, now });
    this.store.setAnalysis(target.id, a);
    this.store.save();
    return a;
  }

  /** Collecte les alertes e-mail Leboncoin reçues dans la boîte IMAP de l'utilisateur. */
  async pollEmail(imap: ImapConfig): Promise<IngestReport> {
    const meta = this.store.meta;
    meta.lastPollAt = new Date().toISOString();
    try {
      const { mails, lastUid } = await fetchAlertMails(imap, meta.imapLastUid, this.cfg.polling.maxEmailsPerPoll);
      const listings = mails.flatMap((m) => parseAlertEmail(m.mail.html || m.mail.text, m.mail.date ? new Date(m.mail.date).toISOString() : undefined));
      const rep = this.ingest(listings);
      meta.imapLastUid = lastUid;
      meta.lastPollOk = new Date().toISOString();
      meta.consecutiveErrors = 0;
      meta.adminAlerted = false;
      meta.lastError = undefined;
      this.log(`📬 ${mails.length} e-mail(s), ${listings.length} annonce(s) lue(s), ${rep.created} nouvelle(s), ${rep.alerts.length} alerte(s)`);
      return rep;
    } catch (e) {
      meta.consecutiveErrors++;
      meta.lastError = (e as Error).message;
      throw e;
    } finally {
      this.store.save();
    }
  }
}
