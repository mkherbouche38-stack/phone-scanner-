#!/data/data/com.termux/files/usr/bin/bash
# Assistant de configuration Carvanta : crée carvanta/.env question par question.
# Lancement (depuis le dossier phone-scanner-) : bash carvanta/setup.sh
cd "$(dirname "$0")" || exit 1

ask() { # ask VAR "Question" [secret]
  local v
  if [ "$3" = "secret" ]; then read -rsp "$2 : " v; echo; else read -rp "$2 : " v; fi
  v="$(printf '%s' "$v" | tr -d '\r\n' | sed 's/^ *//;s/ *$//')"
  [ "$1" = "IMAP_PASSWORD" ] && v="$(printf '%s' "$v" | tr -d ' ')" # Google affiche le mot de passe par blocs de 4
  printf '%s=%s\n' "$1" "$v" >> .env.tmp
}

rm -f .env.tmp
echo "=== Carvanta : configuration ==="
echo "Colle chaque valeur puis appuie sur Entrée. Laisse vide si tu ne l'as pas encore."
echo
ask DISCORD_TOKEN "Token du bot Discord (rien ne s'affiche, c'est normal)" secret
ask DISCORD_APP_ID "Application ID"
ask DISCORD_GUILD_ID "ID du serveur Discord"
ask DISCORD_ALERT_CHANNEL_ID "ID du salon des alertes voitures"
ask ADMIN_USER_IDS "Ton ID Discord (pour les commandes admin)"
echo
echo "--- Alertes e-mail Leboncoin (laisse vide pour plus tard) ---"
ask IMAP_USER "Adresse Gmail qui reçoit les alertes Leboncoin"
ask IMAP_PASSWORD "Mot de passe d'application Gmail (16 lettres)" secret
{
  echo "IMAP_HOST=imap.gmail.com"
  echo "IMAP_PORT=993"
  echo "IMAP_FOLDER=INBOX"
  echo "IMAP_FROM=leboncoin"
} >> .env.tmp
# une ligne IMAP vide désactive la collecte e-mail
grep -q '^IMAP_USER=.\+' .env.tmp || sed -i '/^IMAP_/d' .env.tmp
mv .env.tmp .env
chmod 600 .env
echo
echo "✅ carvanta/.env créé (lisible par toi seul)."
echo "Lance le bot avec :  npx tsx carvanta/bot.ts"
