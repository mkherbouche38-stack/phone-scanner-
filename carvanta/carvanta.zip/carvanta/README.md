# 🚗 Carvanta Scanner

Bot Discord qui repère les voitures d'occasion potentiellement sous-cotées sur Leboncoin, chiffre les réparations
**déclarées**, calcule le coût total et la marge (prudente / centrale / optimiste) et envoie une alerte notée sur 100.
Une marge estimée n'est jamais une garantie de profit.

## Source des annonces : uniquement des méthodes autorisées

Leboncoin ne propose pas d'API publique d'annonces, ses conditions interdisent l'extraction automatisée, et la
justice a déjà condamné un site pour extraction de sa base (Jinka, TJ Nanterre, 31 mai 2024). Carvanta ne fait
donc **aucun scraping** et ne contourne aucune protection. Il utilise :

1. **Tes alertes e-mail Leboncoin** : tu enregistres une recherche (Voitures, 700–2 000 €, ta zone) avec alerte
   par e-mail. Carvanta lit ces e-mails dans **ta** boîte (IMAP, lecture seule) : titre, prix, lieu, lien.
2. **La commande `/analyse`** : tu colles le texte complet d'une annonce. C'est la seule façon d'analyser la
   description, donc les défauts déclarés.

Une alerte e-mail ne contient pas la description : les défauts restent « inconnus » et le score en tient compte
tant que tu n'as pas fait `/analyse`.

## Fichiers

```
carvanta/
├── bot.ts            démarrage, commandes Discord, boucle de collecte
├── service.ts        ingestion, décision d'alerte, collecte e-mail
├── analyze.ts        filtres + chaîne d'analyse
├── parse.ts          lecture des annonces et des e-mails d'alerte, identifiants, empreinte anti-doublon
├── repairs.ts        défauts déclarés → niveaux A / B / C + fourchettes de coûts (barème modifiable)
├── market.ts         prix de marché par comparables (quartiles), confiance
├── profit.ts         coût total, marges, rendement
├── score.ts          score /100 transparent + verdict
├── embed.ts          alertes Discord (noir / blanc / violet) + boutons
├── store.ts          base locale JSON : historique, prix, statut, favoris
├── discord.ts        client Discord sans dépendance (REST + passerelle)
├── imap.ts, mime.ts  lecture des e-mails sans dépendance
├── cli.ts            analyse hors ligne d'un fichier texte
├── setup.sh          assistant qui crée .env
├── config.json       budget, filtres, coûts, seuils (modifiable sans toucher au code)
├── env.example       modèle des variables secrètes
├── exemple-annonce.txt
└── *.test.ts         tests automatisés
```

Aucune dépendance à installer : seulement `tsx`, déjà présent pour le Phone Scanner. Node 22 ou plus récent.

## Installation (Termux)

1. **Créer le bot Discord** (navigateur, mode ordinateur) : https://discord.com/developers/applications → *New Application* « Carvanta ».
   - *General Information* → copie l'**Application ID**.
   - *Bot* → *Reset Token* → copie le **token** (ne le montre à personne).
   - *OAuth2 → URL Generator* : coche `bot` et `applications.commands`, puis les permissions `View Channels`,
     `Send Messages`, `Embed Links`. Ouvre l'URL générée et ajoute le bot à ton serveur.
   - Dans Discord : *Paramètres → Avancés → Mode développeur*. Appui long sur ton serveur → *Copier l'identifiant*
     (Guild ID), sur le salon `#voitures` → *Copier l'identifiant*, sur ton profil → *Copier l'identifiant*.
2. **(Recommandé) Alertes e-mail** : sur Leboncoin, enregistre ta recherche avec alerte par e-mail. Sur Gmail, active
   la validation en 2 étapes puis crée un mot de passe d'application : https://myaccount.google.com/apppasswords
3. **Dans Termux** :
   ```
   cd $HOME/phone-scanner-
   git pull
   bash carvanta/setup.sh
   npx tsx carvanta/bot.ts
   ```
   Dans le salon d'alerte, tu dois voir « 🚗 Carvanta Scanner en ligne ».

## Commandes Discord

| Commande | Rôle |
|---|---|
| `/analyse texte [lien] [cote]` | analyse complète d'une annonce collée ; `cote` = valeur de marché vérifiée par toi |
| `/scan` | relève maintenant les alertes e-mail |
| `/opportunites` | meilleures annonces connues (disponibilité non revérifiée) |
| `/favori id` · `/historique` | favoris et dernières alertes |
| `/status` | état réel : Discord, dernière collecte, erreurs |
| `/budget` · `/region` · `/config` | réglages (admin : gérer le serveur, ou ID dans `ADMIN_USER_IDS`) |

Boutons de chaque alerte : *Voir l'annonce*, *Analyse détaillée*, *Examinée*, *★ Favori*.
Le bot ne contacte jamais un vendeur et n'achète rien.

## Comment c'est calculé

- **Marché** : quartiles des prix demandés d'annonces comparables déjà vues (même marque et modèle, ±2 ans,
  ±40 000 km, 120 jours, carburant et boîte identiques si connus). Il en faut au moins 3, sinon la confiance est
  « aucune » ou « faible » et aucune marge n'est calculée. Ce sont des prix demandés, pas des prix de vente :
  la revente prudente prend le 1er quartile. Au début, la base est vide : utilise l'option `cote` de `/analyse`.
- **Réparations** : barème indicatif (pièces + main-d'œuvre garage) dans `repairs.ts`, à ajuster avec tes devis.
  A = simple, B = à diagnostiquer (haut de fourchette +25 %), C = exclue (moteur, boîte, structure, airbag,
  freinage dangereux, accident). Problème administratif (sans carte grise, gage, export) = rejetée.
- **Coût total** = achat + réparations + transport + carte grise et frais + CT si absent + nettoyage + frais de
  revente + imprévus (10 %, minimum 150 €). **Marge** = revente − coût total. **Rendement** = marge / coût × 100.
  Impôts et statut (particulier, micro-entreprise, marchand VO) non inclus.
- **Score /100** : décote 30, marge prudente 25, facilité des réparations 15, qualité des données 15,
  coût vs budget 10, demande apparente 5. Le détail est dans *Analyse détaillée*.
- **Verdicts** : EXCELLENTE OPPORTUNITÉ À VÉRIFIER, OPPORTUNITÉ INTÉRESSANTE (marge centrale ≥ 400 €),
  À ANALYSER, RISQUE ÉLEVÉ, REJETÉE.

## Tests

```
npx tsx --test carvanta/carvanta.test.ts carvanta/bot.test.ts
npx tsx carvanta/cli.ts carvanta/exemple-annonce.txt 3800
```

## Limites connues

- Le format exact des e-mails d'alerte Leboncoin n'a pas pu être vérifié : la lecture a été testée sur des
  e-mails simulés. Si une alerte réelle est mal lue, transfère-en une pour calibrer `parseAlertEmail`.
- La connexion Discord et Gmail réelles n'ont pas été testées (pas d'accès à tes comptes) ; elles l'ont été contre
  des serveurs simulés.
- Le rayon en kilomètres n'est pas géré (filtre par départements uniquement).
- Revendre régulièrement des voitures achetées pour la revente est une activité commerciale (statut et
  obligations à vérifier).
