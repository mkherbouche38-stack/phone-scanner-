// Lecture des annonces : texte collé par l'utilisateur, alertes e-mail Leboncoin, identifiants et doublons.
import { createHash } from "node:crypto";
import type { CtStatus, Fuel, Gearbox, Listing, Source } from "./types.ts";

export const norm = (s: string) =>
  s.normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[’`]/g, "'").toLowerCase().replace(/\s+/g, " ").trim();

const num = (s: string) => Number(s.replace(/[^\d]/g, ""));

// ---------- Identifiant et URL ----------
const LBC_ID_RE = /leboncoin\.fr\/(?:ad\/)?(?:voitures|vehicules|[a-z_]+)\/(\d{8,12})/i;

/** Normalise une URL Leboncoin (déroule les liens de suivi encodés) et renvoie l'identifiant. */
export function leboncoinId(urlOrText: string): string | undefined {
  let s = urlOrText;
  for (let i = 0; i < 3; i++) {
    try { const d = decodeURIComponent(s); if (d === s) break; s = d; } catch { break; }
  }
  return s.match(LBC_ID_RE)?.[1];
}

export const canonicalUrl = (id: string) => `https://www.leboncoin.fr/ad/voitures/${id}`;

/** Empreinte de secours quand il n'y a pas d'identifiant : marque+modèle+année+km+prix+lieu. */
export function fingerprint(l: Pick<Listing, "title" | "make" | "model" | "year" | "km" | "price" | "location">): string {
  const key = [l.make ?? norm(l.title).slice(0, 40), l.model, l.year, l.km && Math.round(l.km / 1000), l.price, l.location && norm(l.location)]
    .map((x) => (x === undefined ? "" : String(x))).join("|");
  return "h:" + createHash("sha1").update(key).digest("hex").slice(0, 16);
}

// ---------- Marques ----------
const MAKES: [string, RegExp][] = [
  ["peugeot", /peugeot/], ["renault", /renault/], ["citroen", /citroen/], ["dacia", /dacia/],
  ["volkswagen", /volkswagen|\bvw\b/], ["toyota", /toyota/], ["ford", /\bford\b/], ["opel", /\bopel\b/],
  ["fiat", /\bfiat\b/], ["nissan", /nissan/], ["seat", /\bseat\b/], ["skoda", /skoda/], ["bmw", /\bbmw\b/],
  ["audi", /\baudi\b/], ["mercedes", /mercedes/], ["kia", /\bkia\b/], ["hyundai", /hyundai/], ["suzuki", /suzuki/],
  ["mini", /\bmini\b/], ["honda", /honda/], ["mazda", /mazda/], ["volvo", /volvo/], ["smart", /\bsmart\b/],
  ["ds", /\bds\s?[3-9]\b|\bds automobiles\b/], ["alfa romeo", /alfa romeo/], ["lancia", /lancia/],
  ["mitsubishi", /mitsubishi/], ["chevrolet", /chevrolet/], ["jeep", /\bjeep\b/], ["land rover", /land rover/],
  ["tesla", /tesla/], ["mg", /\bmg\b/], ["subaru", /subaru/], ["lexus", /lexus/], ["porsche", /porsche/],
];
const NOT_MODEL = /^(diesel|essence|hybride|electrique|gpl|hdi|tdi|dci|bluehdi|crdi|cdti|ch|cv|tce|vti|puretech|tsi|tfsi|\d\.\d|\d+ ?(ch|cv|kw))$/;

export function detectMakeModel(text: string): { make?: string; model?: string } {
  const t = norm(text);
  for (const [make, re] of MAKES) {
    const m = t.match(re);
    if (!m) continue;
    const after = t.slice((m.index ?? 0) + m[0].length).replace(/^[\s:,-]+/, "").split(/[\s,()/]+/);
    const words: string[] = [];
    for (const w of after) {
      if (!w || NOT_MODEL.test(w) || words.length >= 2) break;
      if (words.length && /^(19|20)\d\d$/.test(w)) break; // « twingo 2008 » : 2008 est l'année, pas le modèle
      words.push(w);
      if (/\d/.test(w)) break; // "308", "clio 3" → on s'arrête après le chiffre
    }
    return { make, model: words.join(" ") || undefined };
  }
  return {};
}

// ---------- Champs ----------
function field(text: string, label: RegExp): string | undefined {
  // le libellé doit commencer la ligne (évite que « Année modèle : 2010 » soit lu comme « Modèle »)
  const m = text.match(new RegExp(`(?:^|\\n)[ \\t]*${label.source}[ \\t]*(?::|\\n)[ \\t]*([^\\n]{1,60})`, "i"));
  return m?.[1]?.trim();
}

function detectFuel(t: string): Fuel | undefined {
  if (/electrique|100 ?% ?electrique/.test(t)) return "electrique";
  if (/hybride/.test(t)) return "hybride";
  if (/\bgpl\b/.test(t)) return "gpl";
  if (/diesel|\bhdi\b|\btdi\b|\bdci\b|\bcrdi\b|\bcdti\b|\bjtd\b|\bd4d\b/.test(t)) return "diesel";
  if (/essence|\btce\b|\bvti\b|puretech|\btsi\b|\btfsi\b/.test(t)) return "essence";
  return undefined;
}

function detectGearbox(t: string): Gearbox | undefined {
  if (/boite (de vitesse[s]? )?:? ?automatique|\bautomatique\b|\bbva\b|\bdsg\b|\bedc\b|\beat[68]\b/.test(t)) return "automatique";
  if (/boite (de vitesse[s]? )?:? ?manuelle|\bmanuelle\b|\bbvm\b/.test(t)) return "manuelle";
  return undefined;
}

function detectCt(t: string): CtStatus {
  if (/contre[- ]visite/.test(t)) return "contre_visite";
  if (/(sans|pas de|plus de) (controle technique|\bct\b)|(controle technique|\bct\b) (a faire|a prevoir|perime|expire|depasse)|ct non fait/.test(t)) return "a_faire";
  if (/(controle technique|\bct\b)\s*(ok|valide|vierge|a jour|fait|de moins de|recent|neuf|sans defaut|r\.?a\.?s)/.test(t)) return "ok";
  return "inconnu";
}

const YEAR_NOW = new Date().getFullYear();
function detectYear(text: string, t: string): number | undefined {
  const f = field(text, /ann[ée]e[- ]mod[èe]le|ann[ée]e/);
  const fromField = f?.match(/\b(19[89]\d|20[0-4]\d)\b/)?.[1];
  const y = Number(fromField ?? t.match(/\b(199\d|20[0-4]\d)\b/)?.[1]);
  return y >= 1980 && y <= YEAR_NOW + 1 ? y : undefined;
}

function detectKm(text: string, t: string): number | undefined {
  const f = field(text, /kilom[ée]trage/);
  const KM = /(?<![\d.,])(\d{1,3}(?:[ .  ]\d{3})+|\d+)\s?(k\s?km|km|kms|kilometres)\b/i;
  const m = (f ?? "").match(KM) ?? t.match(KM);
  if (!m) return undefined;
  let km = num(m[1]);
  if (/^k\s?km/i.test(m[2])) km *= 1000; // « 158k km »
  return km >= 100 && km <= 1_500_000 ? km : undefined;
}

function detectPrice(text: string): number | undefined {
  const f = field(text, /prix/);
  const PRICE = /(?<![\d.,])(\d{1,3}(?:[ .\u202f\u00a0]\d{3})+|\d+)\s?(€|euros?)/i;
  const src = f?.match(PRICE) ?? text.match(PRICE);
  const p = src ? num(src[1]) : NaN;
  return p >= 50 && p <= 500_000 ? p : undefined;
}

function detectLocation(text: string): { location?: string; department?: string } {
  const m = text.match(/([A-ZÀ-Üa-zà-ü' -]{2,40})\s(\d{5})\b/) ?? text.match(/\b(\d{5})\b/);
  if (!m) return {};
  const cp = m.length > 2 ? m[2] : m[1];
  const city = m.length > 2 ? m[1].trim() : undefined;
  const dep = cp.startsWith("20") ? (Number(cp) < 20200 ? "2A" : "2B") : cp.startsWith("97") ? cp.slice(0, 3) : cp.slice(0, 2);
  return { location: city ? `${city} ${cp}` : cp, department: dep };
}

/** Transforme un texte d'annonce (copié depuis Leboncoin) en annonce normalisée. */
export function parseAdText(text: string, opts: { url?: string; source?: Source; title?: string } = {}): Listing {
  const t = norm(text);
  const firstLine = (opts.title ?? text.split("\n").map((x) => x.trim()).find((x) => x.length > 3) ?? "Annonce").slice(0, 120);
  const fm = field(text, /marque/);
  const fmo = field(text, /mod[èe]le/);
  const detected = detectMakeModel(`${fm ?? ""} ${fmo ?? ""} ${firstLine} ${text.slice(0, 400)}`);
  const make = fm ? detectMakeModel(fm).make ?? norm(fm) : detected.make;
  const model = fmo ? norm(fmo).split(" ").slice(0, 2).join(" ") : detected.model;
  const id = opts.url ? leboncoinId(opts.url) : leboncoinId(text);
  const loc = detectLocation(text);
  const base: Listing = {
    id: "",
    url: id ? canonicalUrl(id) : opts.url,
    source: opts.source ?? "manuel",
    title: firstLine,
    make, model,
    engine: t.match(/\b(\d\.\d)\s?(hdi|tdi|dci|tce|vti|puretech|crdi|cdti|tsi|tfsi|i|16v|bluehdi|d)?\b/)?.[0],
    year: detectYear(text, t),
    km: detectKm(text, t),
    price: detectPrice(text),
    ...loc,
    description: text.length > 60 ? text.slice(0, 6000) : undefined,
    fuel: detectFuel(t),
    gearbox: detectGearbox(t),
    ct: detectCt(t),
    seller: /\bprofessionnel\b|\bpro\b|garage/.test(t) ? "pro" : /\bparticulier\b/.test(t) ? "particulier" : undefined,
  };
  base.id = id ? `lbc:${id}` : fingerprint(base);
  return base;
}

// ---------- E-mails d'alerte Leboncoin ----------
const decodeEntities = (s: string) =>
  s.replace(/&nbsp;|&#160;/g, " ").replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'")
    .replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&euro;|&#8364;/g, "€").replace(/&#(\d+);/g, (_, n) => String.fromCharCode(Number(n)));

export const htmlToText = (html: string) =>
  decodeEntities(html.replace(/<(script|style)[\s\S]*?<\/\1>/gi, " ").replace(/<br\s*\/?>|<\/(p|div|tr|td|li|h\d)>/gi, "\n").replace(/<[^>]+>/g, " "))
    .replace(/[ \t  ]+/g, " ").replace(/\n\s*/g, "\n").trim();

/**
 * Extrait les annonces d'un e-mail d'alerte (HTML ou texte).
 * Chaque bloc autour d'un lien d'annonce donne titre / prix / lieu. Les alertes ne contiennent pas
 * la description : les défauts restent inconnus jusqu'à une analyse complète (/analyse).
 */
export function parseAlertEmail(body: string, receivedAt = new Date().toISOString()): Listing[] {
  const html = /<[a-z][\s\S]*>/i.test(body) ? body : "";
  const out = new Map<string, Listing>();
  const anchors = [...(html || body).matchAll(/href=["']([^"']+)["']|(https?:\/\/\S+)/gi)];
  const positions: { id: string; idx: number }[] = [];
  for (const a of anchors) {
    const id = leboncoinId(a[1] ?? a[2] ?? "");
    if (id && !positions.some((p) => p.id === id)) positions.push({ id, idx: a.index ?? 0 });
  }
  positions.forEach((p, i) => {
    const src = html || body;
    const end = positions[i + 1]?.idx ?? Math.min(src.length, p.idx + 4000);
    // bloc = du premier lien de cette annonce jusqu'au premier lien de la suivante
    const start = Math.max(0, src.lastIndexOf("<", p.idx));
    const block = html ? htmlToText(src.slice(start, end)) : src.slice(start, end);
    const lines = block.split("\n").map((x) => x.trim()).filter((x) => x && !/^https?:/.test(x));
    const title = lines.find((x) => detectMakeModel(x).make && !/€/.test(x)) ?? lines.find((x) => x.length > 6 && !/€/.test(x)) ?? "Annonce Leboncoin";
    const l = parseAdText(block, { url: canonicalUrl(p.id), source: "email", title });
    l.description = undefined; // une alerte n'est pas une description
    l.publishedAt = receivedAt;
    out.set(l.id, l);
  });
  return [...out.values()];
}
