// Tests : npx tsx --test carvanta/carvanta.test.ts
import assert from "node:assert/strict";
import { mkdtempSync, readFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { test } from "node:test";
import { analyse, checkFilters } from "./analyze.ts";
import { DEFAULT_CONFIG, type Config } from "./config.ts";
import { alertEmbed, detailText } from "./embed.ts";
import { median, quantile } from "./market.ts";
import { decodeMime } from "./mime.ts";
import { leboncoinId, parseAdText, parseAlertEmail } from "./parse.ts";
import { computeProfit } from "./profit.ts";
import { analyseRepairs } from "./repairs.ts";
import { VERDICT_RANK } from "./score.ts";
import { Store } from "./store.ts";
import type { Listing, StoredListing } from "./types.ts";

const cfg: Config = structuredClone(DEFAULT_CONFIG);
const NOW = new Date("2026-10-14T10:00:00Z");

const comp = (i: number, price: number, extra: Partial<Listing> = {}): StoredListing => ({
  listing: { id: `lbc:10000000${i}`, source: "email", title: "Peugeot 207", make: "peugeot", model: "207", year: 2010, km: 160000, price, ct: "inconnu", fuel: "diesel", ...extra },
  firstSeen: NOW.toISOString(), lastSeen: NOW.toISOString(), priceHistory: [], status: "nouvelle", favorite: false, alerted: false,
});
const POOL = [3200, 3400, 3500, 3600, 3700, 3900, 4100, 4200].map((p, i) => comp(i, p));

const AD = `Peugeot 207 1.6 HDi 90ch
1 400 €
Montpellier 34000
Marque : Peugeot
Modèle : 207
Année modèle : 2010
Kilométrage : 158 000 km
Carburant : Diesel
Boîte de vitesse : Manuelle
Particulier. Contrôle technique OK de moins de 6 mois. Voiture saine, pas de fuite, aucun voyant.
Ampoule de feu arrière grillée et essuie-glaces à changer. Distribution faite à 140 000 km.`;

test("parsing d'une annonce collée", () => {
  const l = parseAdText(AD, { url: "https://www.leboncoin.fr/ad/voitures/2845123456" });
  assert.equal(l.id, "lbc:2845123456");
  assert.equal(l.make, "peugeot");
  assert.equal(l.model, "207");
  assert.equal(l.year, 2010);
  assert.equal(l.km, 158000);
  assert.equal(l.price, 1400);
  assert.equal(l.fuel, "diesel");
  assert.equal(l.gearbox, "manuelle");
  assert.equal(l.ct, "ok");
  assert.equal(l.department, "34");
  assert.equal(l.seller, "particulier");
});

test("identifiant Leboncoin depuis un lien de suivi encodé", () => {
  assert.equal(leboncoinId("https://click.example.com/?u=https%3A%2F%2Fwww.leboncoin.fr%2Fad%2Fvoitures%2F2901234567%3Futm%3Dx"), "2901234567");
  assert.equal(leboncoinId("https://www.leboncoin.fr/voitures/2711111111.htm"), "2711111111");
  assert.equal(leboncoinId("https://www.google.com"), undefined);
});

test("classement des risques : négations et travaux déjà faits ignorés", () => {
  const r = analyseRepairs("Pas de fuite, aucun voyant, embrayage neuf, distribution faite. Ampoule grillée. Pneus à changer.");
  const keys = r.items.map((i) => i.key).sort();
  assert.deepEqual(keys, ["ampoule", "pneus"]);
  assert.equal(r.hasMajorRisk, false);
});

test("classement des risques : défauts majeurs et administratifs", () => {
  const r = analyseRepairs("Joint de culasse à faire, chauffe beaucoup. Vendue sans carte grise.");
  assert.ok(r.items.some((i) => i.key === "culasse" && i.level === "C"));
  assert.equal(r.hasMajorRisk, true);
  assert.ok(r.admin.some((a) => a.key === "carte_grise"));
  assert.equal(analyseRepairs("Certificat de non gage fourni, non gagé.").admin.length, 0);
  assert.ok(analyseRepairs("Véhicule gagé, à solder.").admin.some((a) => a.key === "gage"));
});

test("quartiles et médiane", () => {
  assert.equal(median([1, 3, 2]), 2);
  assert.equal(quantile([100, 200, 300, 400, 500], 0.25), 200);
  assert.ok(Number.isNaN(median([])));
});

test("marge, fourchettes et rendement (formules)", () => {
  const l = parseAdText(AD);
  const rep = analyseRepairs(l.description);
  const market = { comparables: 8, prudent: 3400, central: 3650, optimistic: 3950, method: "test", confidence: "bonne" as const, date: NOW.toISOString() };
  const p = computeProfit(l, rep, market, cfg.costs);
  // réparations A : ampoule 10-60 + essuie 15-40 → 25-100, pas de majoration (que du A)
  assert.deepEqual(p.repairs, { low: 25, mid: 63, high: 100 });
  assert.equal(p.ct, 0); // CT OK
  const fixed = cfg.costs.transport + cfg.costs.registration + cfg.costs.adminFees + cfg.costs.cleaning + cfg.costs.sellingFees;
  assert.equal(p.total.high, 1400 + 100 + fixed + Math.max(cfg.costs.contingencyMin, (1400 + 100) * 0.1));
  assert.equal(p.margin!.prudent, 3400 - p.total.high);
  assert.equal(p.margin!.central, 3650 - p.total.mid);
  assert.equal(p.roi!.central, Math.round(((3650 - p.total.mid) / p.total.mid) * 1000) / 10);
});

test("réparation plus chère que prévu → marge négative → REJETÉE", () => {
  const text = AD.replace("Ampoule de feu arrière grillée", "Embrayage qui patine, amortisseurs à changer, fuite d'huile, voyant moteur allumé");
  const a = analyse(parseAdText(text.replace("1 400 €", "3 300 €")), POOL, cfg, { now: NOW });
  assert.ok(a.profit.margin!.central < 0, `marge centrale ${a.profit.margin!.central}`);
  assert.equal(a.score.verdict, "REJETÉE");
});

test("bonne affaire bien documentée → opportunité, score détaillé", () => {
  const a = analyse(parseAdText(AD), POOL, cfg, { now: NOW });
  assert.equal(a.market.comparables, 8);
  assert.ok(a.profit.margin!.prudent > 0);
  assert.ok(["EXCELLENTE OPPORTUNITÉ À VÉRIFIER", "OPPORTUNITÉ INTÉRESSANTE"].includes(a.score.verdict), a.score.verdict);
  assert.equal(a.score.factors.reduce((s, f) => s + f.max, 0), 100);
  assert.equal(a.score.factors.reduce((s, f) => s + f.points, 0), a.score.score);
});

test("défaut de sécurité → jamais recommandé, même avec grosse marge", () => {
  const a = analyse(parseAdText(AD.replace("Ampoule de feu arrière grillée", "Ne freine plus du tout").replace("1 400 €", "700 €")), POOL, cfg, { now: NOW });
  assert.equal(a.score.verdict, "RISQUE ÉLEVÉ");
  assert.ok(a.score.risks.some((r) => r.includes("Freinage")));
});

test("kilométrage manquant et comparables insuffisants → confiance faible, pas de marge inventée", () => {
  const l = parseAdText("Renault Twingo 2008\n900 €\nBéziers 34500\nRAS");
  assert.equal(l.km, undefined);
  const a = analyse(l, [], cfg, { now: NOW });
  assert.equal(a.market.confidence, "aucune");
  assert.equal(a.profit.margin, undefined);
  assert.equal(a.score.verdict, "À ANALYSER");
  assert.ok(a.score.missing.includes("kilométrage"));
});

test("prix incohérent (très en dessous du marché) signalé", () => {
  const a = analyse(parseAdText(AD.replace("1 400 €", "600 €")), POOL, cfg, { now: NOW });
  assert.ok(a.score.risks.some((r) => r.includes("arnaque")));
  assert.equal(a.score.budgetCategory, "prix exceptionnellement bas");
});

test("filtres configurables", () => {
  const l = parseAdText(AD);
  assert.deepEqual(checkFilters(l, { ...cfg.filters, departments: ["13"] }), ["département 34 hors zone"]);
  assert.deepEqual(checkFilters(l, { ...cfg.filters, kmMax: 150000 }), ["158000 km > 150000"]);
  assert.deepEqual(checkFilters(l, cfg.filters), []);
});

test("anti-doublons : même id, changement de prix, empreinte de secours", () => {
  const s = new Store(join(mkdtempSync(join(tmpdir(), "cv-")), "db.json"));
  const l = parseAdText(AD, { url: "https://www.leboncoin.fr/ad/voitures/2845123456" });
  assert.equal(s.upsert(l).isNew, true);
  assert.equal(s.upsert(l).isNew, false);
  const cheaper = { ...l, price: 1250 };
  assert.deepEqual(s.upsert(cheaper).priceChange, { from: 1400, to: 1250 });
  // même voiture republiée sans identifiant → doublon détecté par empreinte
  const copy = { ...cheaper, id: "h:autre", url: undefined };
  assert.equal(s.upsert(copy).duplicateOf, "lbc:2845123456");
  // une alerte e-mail sans description n'efface pas la description connue
  s.upsert({ ...l, description: undefined, price: 1250 });
  assert.ok(s.get("lbc:2845123456")!.listing.description);
  s.save();
  assert.equal(new Store(s.path).all().length, 1);
});

test("e-mail d'alerte : plusieurs annonces extraites, sans doublon", () => {
  const html = `<html><body><table>
    <tr><td><a href="https://www.leboncoin.fr/ad/voitures/2900000001?utm_source=alert"><img src="x.jpg"></a></td>
    <td><a href="https://www.leboncoin.fr/ad/voitures/2900000001?utm_source=alert">Renault Clio 3 1.5 dCi</a><br>1&nbsp;600&nbsp;€<br>Sète 34200</td></tr>
    <tr><td><a href="https://www.leboncoin.fr/ad/voitures/2900000002">Peugeot 206 1.4 essence 2005</a><br>950 €<br>Nîmes 30000</td></tr>
  </table></body></html>`;
  const ads = parseAlertEmail(html);
  assert.equal(ads.length, 2);
  assert.equal(ads[0].id, "lbc:2900000001");
  assert.equal(ads[0].make, "renault");
  assert.equal(ads[0].price, 1600);
  assert.equal(ads[0].department, "34");
  assert.equal(ads[1].price, 950);
  assert.equal(ads[1].description, undefined);
});

test("MIME : quoted-printable et base64 multipart", () => {
  const raw = [
    "From: Leboncoin <noreply@leboncoin.fr>", "Subject: =?UTF-8?Q?Nouvelles_annonces_=C3=A0_voir?=",
    'Content-Type: multipart/alternative; boundary="b1"', "", "--b1",
    "Content-Type: text/plain; charset=utf-8", "Content-Transfer-Encoding: quoted-printable", "",
    "Prix : 1 200 =E2=82=AC", "--b1", "Content-Type: text/html; charset=utf-8", "Content-Transfer-Encoding: base64", "",
    Buffer.from("<p>Clio 1 200 €</p>").toString("base64"), "--b1--",
  ].join("\r\n");
  const m = decodeMime(raw);
  assert.equal(m.subject, "Nouvelles annonces à voir");
  assert.match(m.text, /1 200 €/);
  assert.match(m.html, /Clio/);
});

test("embed Discord : limites respectées et infos clés présentes", () => {
  const a = analyse(parseAdText(AD, { url: "https://www.leboncoin.fr/ad/voitures/2845123456" }), POOL, cfg, { now: NOW });
  const e = alertEmbed(a);
  const size = (e.title?.length ?? 0) + (e.description?.length ?? 0) + e.fields.reduce((s, f) => s + f.name.length + f.value.length, 0) + (e.footer?.text.length ?? 0);
  assert.ok(size < 6000, `taille ${size}`);
  assert.ok(e.fields.length <= 25);
  assert.ok(e.fields.every((f) => f.value.length <= 1024 && f.name.length <= 256));
  assert.equal(e.url, "https://www.leboncoin.fr/ad/voitures/2845123456");
  const all = JSON.stringify(e);
  for (const k of ["Prix demandé", "Marché", "Coût total", "Revente", "Marge", "Score", "lbc:2845123456"]) assert.ok(all.includes(k), k);
  assert.ok(detailText(a).length <= 2000);
});

test("prix bas mais marge centrale trop faible → À ANALYSER, pas d'opportunité", () => {
  const text = "Peugeot 207 1.6 HDi\n1 400 €\nMontpellier 34000\nAnnée modèle : 2010\nKilométrage : 158 000 km\nDiesel, manuelle, CT OK. Embrayage qui patine, pneus à changer.";
  const a = analyse(parseAdText(text), [], cfg, { userValue: 3600, now: NOW });
  assert.equal(a.listing.model, "207", "« Année modèle » ne doit pas être lu comme le modèle");
  assert.ok(a.profit.margin!.central < cfg.opportunities.minCentralMargin);
  assert.equal(a.score.verdict, "À ANALYSER");
});

test("« pare-choc arrière » n'est pas un accident ; l'exemple fourni est une opportunité", () => {
  assert.equal(analyseRepairs("Petite rayure sur le pare-choc arrière.").hasMajorRisk, false);
  assert.equal(analyseRepairs("Choc avant important, airbags sortis.").hasMajorRisk, true);
  const text = readFileSync(new URL("./exemple-annonce.txt", import.meta.url), "utf8");
  const a = analyse(parseAdText(text), [], cfg, { userValue: 3800, now: NOW });
  assert.ok(VERDICT_RANK[a.score.verdict] >= VERDICT_RANK["OPPORTUNITÉ INTÉRESSANTE"], a.score.verdict);
});
