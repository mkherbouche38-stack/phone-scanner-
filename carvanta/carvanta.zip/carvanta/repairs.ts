// Analyse des défauts DÉCLARÉS dans l'annonce. Aucun diagnostic certain : ce sont des fourchettes indicatives.
// Méthode : barème interne (pièces + main-d'œuvre garage, véhicule citadine/compacte courante, 2025-2026),
// à ajuster dans ce fichier selon tes propres devis. Les fourchettes sont volontairement larges.
import { norm } from "./parse.ts";
import type { AdminIssue, RepairAnalysis, RepairItem, RepairLevel } from "./types.ts";

interface Rule {
  key: string; label: string; level: RepairLevel; re: RegExp;
  low: number; high: number; parts: string; labour: string; diy: boolean; safety?: boolean;
}

// Ordre important : les règles C (graves) passent avant les règles B plus générales.
const RULES: Rule[] = [
  // ---- C : risques majeurs, exclus des recommandations ----
  { key: "culasse", label: "Joint de culasse / surchauffe", level: "C", re: /joint de culasse|culasse|surchauf|chauffe (beaucoup|trop)|melange eau.?huile|mayonnaise/, low: 900, high: 2500, parts: "joint, visserie, liquide", labour: "garage, 8-15 h", diy: false },
  { key: "moteur", label: "Moteur HS / casse moteur", level: "C", re: /moteur (hs|casse|mort|a refaire|qui cogne|claque|fume (bleu|blanc))|casse moteur|bielle|segmentation|consomme (beaucoup d')?huile|bruit (moteur|de cognement)/, low: 1500, high: 5000, parts: "moteur d'occasion ou réfection", labour: "garage", diy: false },
  { key: "boite", label: "Boîte de vitesses défaillante", level: "C", re: /boite (de vitesses? )?(hs|cassee|a refaire|qui craque|craque|bruyante)|(vitesse|rapport)s? (qui )?(craque|saute|passe mal)|probleme de boite/, low: 800, high: 3000, parts: "boîte d'occasion ou réfection", labour: "garage", diy: false },
  { key: "turbo", label: "Turbo défaillant", level: "C", re: /turbo (hs|siffle|fuit|a changer|mort)|probleme (de )?turbo/, low: 700, high: 2000, parts: "turbo + joints", labour: "garage", diy: false },
  { key: "structure", label: "Structure / châssis / corrosion grave", level: "C", re: /chassis|longeron|structure|rouille (importante|perforante|traversante)|perfor(e|ation)|plancher (rouille|perce)/, low: 800, high: 4000, parts: "tôlerie", labour: "carrossier", diy: false, safety: true },
  { key: "airbag", label: "Airbag / voyant airbag", level: "C", re: /airbag/, low: 200, high: 1500, parts: "airbag, capteur, calculateur", labour: "garage", diy: false, safety: true },
  { key: "freins_dangereux", label: "Freinage dangereux", level: "C", re: /ne freine (plus|pas|mal)|freins? hs|plus de freins?|pedale de frein (molle|au plancher)/, low: 200, high: 1200, parts: "disques, plaquettes, étriers, maître-cylindre", labour: "garage", diy: false, safety: true },
  { key: "accident", label: "Accident / inondation / épave", level: "C", re: /accidente|(?<!pare.?)choc (avant|arriere|lateral|important)|sinistre|inonde|dans l'eau|epave|\bvei\b|\bvge\b|\bvrade\b|reparable economiquement/, low: 1000, high: 6000, parts: "selon dégâts", labour: "carrossier / expert", diy: false, safety: true },

  // ---- B : à faire diagnostiquer ----
  { key: "embrayage", label: "Embrayage", level: "B", re: /embrayage|patine|volant moteur/, low: 500, high: 1300, parts: "kit embrayage (+ volant moteur bimasse éventuel)", labour: "garage, 4-8 h", diy: false },
  { key: "distribution", label: "Courroie de distribution à faire", level: "B", re: /distribution|courroie de distri/, low: 350, high: 900, parts: "kit distribution + pompe à eau", labour: "garage, 3-6 h", diy: false },
  { key: "voyant", label: "Voyant moteur allumé", level: "B", re: /voyant (moteur|orange|allume|anti.?pollution|injection)|\bvoyant\b|mode degrade/, low: 80, high: 1200, parts: "selon code défaut (lecture OBD indispensable)", labour: "diagnostic 50-90 €", diy: false },
  { key: "demarrage", label: "Démarrage difficile / ne démarre pas", level: "B", re: /ne demarre (plus|pas)|demarrage difficile|demarre mal|non roulant|ne roule (plus|pas)/, low: 80, high: 1500, parts: "batterie, démarreur, bougies, injecteurs… selon diagnostic", labour: "diagnostic puis réparation", diy: false },
  { key: "puissance", label: "Perte de puissance (cause inconnue)", level: "B", re: /perte de puissance|manque de puissance|broute|a.?coups/, low: 100, high: 2000, parts: "selon diagnostic (EGR, injecteurs, turbo…)", labour: "diagnostic indispensable", diy: false },
  { key: "egr_fap", label: "Vanne EGR / FAP", level: "B", re: /\begr\b|\bfap\b|filtre a particules|adblue/, low: 150, high: 1500, parts: "nettoyage ou remplacement", labour: "garage", diy: false },
  { key: "refroidissement", label: "Circuit de refroidissement", level: "B", re: /radiateur|durite|pompe a eau|liquide de refroidissement|vase d'expansion|ventilateur/, low: 100, high: 600, parts: "radiateur / durite / pompe", labour: "garage ou amateur expérimenté", diy: false },
  { key: "fuite", label: "Fuite (huile, liquide)", level: "B", re: /fuite|suinte|suintement/, low: 100, high: 900, parts: "joints selon origine", labour: "diagnostic nécessaire", diy: false },
  { key: "freins", label: "Freins à faire", level: "B", re: /plaquette|disques? de frein|freins? a (faire|changer|prevoir)|frein a main/, low: 120, high: 450, parts: "plaquettes / disques", labour: "garage 1-2 h", diy: false, safety: true },
  { key: "pneus", label: "Pneus à changer", level: "B", re: /pneus? (a changer|use|lisse|a prevoir|limite)|changer (les )?pneus/, low: 150, high: 450, parts: "2 à 4 pneus + montage", labour: "centre pneus", diy: false, safety: true },
  { key: "suspension", label: "Suspension / train roulant", level: "B", re: /amortisseur|suspension|rotule|silent.?bloc|cardan|biellette|triangle|bruit (en|dans les) virage/, low: 150, high: 800, parts: "amortisseurs, rotules, cardans…", labour: "garage", diy: false, safety: true },
  { key: "echappement", label: "Échappement", level: "B", re: /echappement|silencieux|pot (troue|perce|a changer)|catalyseur/, low: 80, high: 700, parts: "silencieux / catalyseur", labour: "garage", diy: false },
  { key: "clim", label: "Climatisation", level: "B", re: /clim(atisation)? (hs|ne marche|a recharger|a faire|ne fonctionne)|recharge (de )?clim/, low: 70, high: 700, parts: "recharge ou compresseur", labour: "garage", diy: false },
  { key: "electrique", label: "Problème électrique", level: "B", re: /probleme electrique|faisceau|calculateur|leve.?vitre|vitre electrique|fermeture centralisee|electronique/, low: 50, high: 700, parts: "selon panne", labour: "diagnostic nécessaire", diy: false },
  { key: "contre_visite", label: "Contre-visite contrôle technique", level: "B", re: /contre[- ]visite/, low: 100, high: 800, parts: "selon défauts du PV", labour: "selon défauts", diy: false },

  // ---- A : potentiellement simples (cause identifiée) ----
  { key: "batterie", label: "Batterie (à confirmer par un test)", level: "A", re: /batterie/, low: 80, high: 180, parts: "batterie", labour: "amateur, 20 min — tester aussi l'alternateur", diy: true },
  { key: "ampoule", label: "Ampoule / feu", level: "A", re: /ampoule|feu (grille|hs|ne marche)|phare (grille|hs)|clignotant/, low: 10, high: 60, parts: "ampoule", labour: "amateur", diy: true },
  { key: "essuie", label: "Essuie-glaces", level: "A", re: /essuie.?glace/, low: 15, high: 40, parts: "balais", labour: "amateur", diy: true },
  { key: "nettoyage", label: "Nettoyage / intérieur sale", level: "A", re: /a nettoyer|\bsale\b|nettoyage a prevoir|odeur|\btaches?\b/, low: 30, high: 150, parts: "produits", labour: "amateur", diy: true },
  { key: "finition", label: "Petits éléments de finition", level: "A", re: /retroviseur|enjoliveur|poignee|pare.?soleil|\bcache\b|baguette|antenne/, low: 15, high: 120, parts: "pièce d'occasion", labour: "amateur", diy: true },
  { key: "carrosserie", label: "Rayures / petites bosses (esthétique)", level: "A", re: /rayure|bosse|bosselette|choc leger|eraflure|pare.?choc (raye|abime)|carrosserie (abimee|a reprendre)/, low: 0, high: 400, parts: "optionnel (esthétique)", labour: "débosseleur / amateur", diy: true },
];

// Problèmes administratifs / juridiques : on écarte jusqu'à clarification.
const ADMIN: { key: string; label: string; re: RegExp }[] = [
  { key: "carte_grise", label: "Carte grise absente ou perdue", re: /sans (carte grise|papiers?|cg)|carte grise (perdue|absente|pas a (mon|son) nom)|pas de (carte grise|papiers)|cg perdue/ },
  { key: "gage", label: "Véhicule gagé / opposition", re: /\bgagee?\b|opposition/ },
  { key: "export", label: "Vente export / pour pièces uniquement", re: /export (uniquement|seulement)|pour pieces|vendu pour pieces|\bw garage\b/ },
  { key: "ve", label: "Procédure véhicule endommagé (VE)", re: /procedure ve\b|\bve\b en cours|vehicule endommage/ },
];

const NEGATED = /(pas de|pas d'|aucun|aucune|sans|non|jamais|ni|zero|0)\s+(\S+\s+){0,2}$/;
const DONE_AFTER = /^\W*(\S+\s+){0,3}(neuf|neuve|neufs|neuves|fait|faite|faits|faites|change|changee|changes|remplace|remplacee|refait|refaite|ok|recent|recente|recemment|sain|saine|propre|impeccable|parfait)\b/;

export function analyseRepairs(description: string | undefined): RepairAnalysis {
  const text = description ? norm(description) : "";
  const items: RepairItem[] = [];
  const admin: AdminIssue[] = [];
  const used = new Set<string>();

  for (const r of RULES) {
    for (const m of text.matchAll(new RegExp(r.re.source, "g"))) {
      const i = m.index ?? 0;
      // la négation / le « déjà fait » ne valent que dans la même phrase
      const before = text.slice(Math.max(0, i - 25), i).split(/[.!?;,]/).pop()!;
      const after = text.slice(i + m[0].length, i + m[0].length + 40).split(/[.!?;,]/)[0];
      if (NEGATED.test(before) || DONE_AFTER.test(after)) continue; // « pas de fuite », « embrayage neuf »
      // une zone de texte déjà expliquée par une règle plus grave n'est pas recomptée
      const span = `${Math.floor(i / 15)}`;
      if (used.has(span) && r.level !== "C") continue;
      used.add(span);
      if (!items.some((x) => x.key === r.key)) {
        items.push({
          key: r.key, label: r.label, level: r.level, low: r.low, high: r.high, parts: r.parts, labour: r.labour,
          diy: r.diy, safety: Boolean(r.safety), confidence: r.level === "A" ? "moyenne" : "faible",
          evidence: text.slice(Math.max(0, i - 20), i + m[0].length + 20).trim(),
        });
      }
      break;
    }
  }
  for (const a of ADMIN) {
    const m = text.match(a.re);
    if (m && !/non gage|pas gage|aucun gage|sans gage/.test(text.slice(Math.max(0, (m.index ?? 0) - 6), (m.index ?? 0) + m[0].length))) {
      admin.push({ key: a.key, label: a.label, evidence: m[0] });
    }
  }
  return {
    items, admin,
    low: items.reduce((s, x) => s + x.low, 0),
    high: items.reduce((s, x) => s + x.high, 0),
    hasMajorRisk: items.some((x) => x.level === "C"),
    descriptionKnown: Boolean(description && description.length > 60),
  };
}
