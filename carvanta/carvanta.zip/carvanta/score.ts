// Score transparent sur 100 + verdict. Les problèmes de sécurité / juridiques bloquent toute recommandation positive.
import type { Config } from "./config.ts";
import type { Listing, MarketEstimate, ProfitResult, RepairAnalysis, ScoreFactor, ScoreResult, Verdict } from "./types.ts";

const clamp = (n: number, a: number, b: number) => Math.max(a, Math.min(b, n));
const eur = (n: number) => `${Math.round(n).toLocaleString("fr-FR")} €`;

export const VERDICT_RANK: Record<Verdict, number> = {
  "REJETÉE": 0, "RISQUE ÉLEVÉ": 1, "À ANALYSER": 2, "OPPORTUNITÉ INTÉRESSANTE": 3, "EXCELLENTE OPPORTUNITÉ À VÉRIFIER": 4,
};

export function missingInfo(l: Listing, repairs: RepairAnalysis): string[] {
  const m: string[] = [];
  if (!l.price) m.push("prix");
  if (!l.make || !l.model) m.push("marque / modèle");
  if (!l.year) m.push("année");
  if (!l.km) m.push("kilométrage");
  if (!l.fuel) m.push("carburant");
  if (!l.gearbox) m.push("boîte de vitesses");
  if (l.ct === "inconnu") m.push("contrôle technique");
  if (!repairs.descriptionKnown) m.push("description complète (défauts déclarés)");
  if (!l.location) m.push("localisation");
  return m;
}

export function scoreListing(
  l: Listing, repairs: RepairAnalysis, market: MarketEstimate, profit: ProfitResult, cfg: Config,
): ScoreResult {
  const factors: ScoreFactor[] = [];
  const risks: string[] = [];
  const reasons: string[] = [];
  const missing = missingInfo(l, repairs);
  const price = l.price ?? 0;

  // 1) Décote observée (30 pts)
  const discount = market.central && price ? (market.central - price) / market.central : 0;
  const dPts = clamp(Math.round(discount * 100), 0, 30);
  factors.push({ label: "Décote vs marché", points: dPts, max: 30,
    why: market.central ? `${Math.round(discount * 100)} % sous la médiane (${eur(market.central)})` : "pas de prix de marché fiable" });

  // 2) Marge prudente (25 pts : 0 € → 0 pt, ≥ 1 000 € → 25 pts)
  const mp = profit.margin?.prudent;
  const mPts = mp === undefined ? 0 : clamp(Math.round((mp / 1000) * 25), 0, 25);
  factors.push({ label: "Marge prudente", points: mPts, max: 25, why: mp === undefined ? "non calculable" : eur(mp) });

  // 3) Facilité des réparations (15 pts)
  const nB = repairs.items.filter((i) => i.level === "B").length;
  const nA = repairs.items.filter((i) => i.level === "A").length;
  let rPts = repairs.descriptionKnown ? 15 - nB * 4 - nA : 6;
  if (repairs.hasMajorRisk) rPts = 0;
  rPts = clamp(rPts, 0, 15);
  factors.push({ label: "Facilité des réparations", points: rPts, max: 15,
    why: !repairs.descriptionKnown ? "défauts inconnus (description non lue)" : repairs.items.length ? `${nA} simple(s), ${nB} à diagnostiquer` : "aucun défaut déclaré" });

  // 4) Qualité des données (15 pts)
  const qBase = 9 - Math.min(missing.length, 9);
  const qMarket = { aucune: 0, faible: 1, moyenne: 4, bonne: 6 }[market.confidence];
  const qPts = clamp(qBase + qMarket, 0, 15);
  factors.push({ label: "Qualité des données", points: qPts, max: 15, why: `${missing.length} info(s) manquante(s), confiance marché ${market.confidence}` });

  // 5) Coût total vs budget (10 pts)
  const inBudget = price >= cfg.budget.min && price <= cfg.budget.max;
  const bPts = !price ? 0 : inBudget ? (profit.total.high <= cfg.budget.max * 1.3 ? 10 : 7) : price < cfg.budget.min ? 6 : 3;
  factors.push({ label: "Coût engagé vs budget", points: bPts, max: 10, why: `coût total ${eur(profit.total.low)} – ${eur(profit.total.high)}` });

  // 6) Demande apparente (5 pts) — approximation : nombre d'annonces similaires observées
  const dm = clamp(Math.round(market.comparables / 2), 0, 5);
  factors.push({ label: "Demande apparente", points: dm, max: 5, why: `${market.comparables} annonce(s) similaire(s) observée(s) (approximation)` });

  let score = factors.reduce((s, f) => s + f.points, 0);

  // ---- Risques ----
  for (const i of repairs.items) {
    if (i.level === "C") risks.push(`⛔ ${i.label}`);
    else if (i.safety) risks.push(`⚠️ ${i.label} (sécurité : ne pas rouler avant contrôle)`);
  }
  for (const a of repairs.admin) risks.push(`⛔ ${a.label} — à clarifier avant tout`);
  if (price && market.central && price < market.central * 0.35) risks.push("⚠️ Prix très en dessous du marché : vérifier arnaque / défaut caché / situation administrative");
  if (l.km && l.year && l.km / Math.max(1, new Date().getFullYear() - l.year + 0.5) > 35000) risks.push("⚠️ Kilométrage annuel très élevé");
  if (l.km && l.year && l.km < 2000 * Math.max(1, new Date().getFullYear() - l.year) && new Date().getFullYear() - l.year > 8) risks.push("⚠️ Kilométrage anormalement bas pour l'âge : vérifier l'historique");

  // ---- Catégorie budget ----
  const exceptional = discount * 100 >= cfg.opportunities.exceptionalDiscountPct || (price > 0 && price < cfg.budget.min);
  const budgetCategory: ScoreResult["budgetCategory"] = inBudget ? (exceptional ? "prix exceptionnellement bas" : "dans le budget")
    : price < cfg.budget.min ? "prix exceptionnellement bas"
    : (mp ?? -1) >= cfg.opportunities.outOfBudgetMinPrudentMargin ? "hors budget à fort potentiel" : "hors budget";

  // ---- Verdict ----
  let verdict: Verdict;
  if (repairs.admin.length) { verdict = "REJETÉE"; reasons.push("Situation administrative ou juridique à clarifier : exclue."); score = Math.min(score, 15); }
  else if (repairs.hasMajorRisk) { verdict = "RISQUE ÉLEVÉ"; reasons.push("Défaut majeur déclaré (moteur, boîte, structure, sécurité…) : exclue des recommandations."); score = Math.min(score, 30); }
  else if (!profit.margin) { verdict = "À ANALYSER"; reasons.push("Pas assez de comparables pour estimer la revente : à analyser manuellement."); }
  else if (profit.margin.central < 0) { verdict = "REJETÉE"; reasons.push(`Marge centrale négative (${eur(profit.margin.central)}).`); }
  else if (score >= 75 && profit.margin.prudent > 0 && profit.margin.central >= cfg.opportunities.minCentralMargin) verdict = "EXCELLENTE OPPORTUNITÉ À VÉRIFIER";
  else if (score >= 55 && profit.margin.central >= cfg.opportunities.minCentralMargin) verdict = "OPPORTUNITÉ INTÉRESSANTE";
  else if (profit.margin.central < cfg.opportunities.minCentralMargin) {
    verdict = "À ANALYSER";
    reasons.push(`Marge centrale (${eur(profit.margin.central)}) sous le seuil de ${eur(cfg.opportunities.minCentralMargin)} : le prix bas ne suffit pas.`);
  }
  else if (score >= 35) verdict = "À ANALYSER";
  else verdict = "REJETÉE";

  if (budgetCategory === "hors budget" && VERDICT_RANK[verdict] > VERDICT_RANK["À ANALYSER"]) {
    verdict = "À ANALYSER";
    reasons.push("Hors budget sans marge prudente suffisante.");
  }
  if (profit.margin && profit.margin.prudent > 0) reasons.push(`Marge positive même dans le scénario prudent (${eur(profit.margin.prudent)}).`);
  if (dPts >= 20) reasons.push(`Forte décote observée (${Math.round(discount * 100)} %).`);
  if (repairs.descriptionKnown && !repairs.items.length) reasons.push("Aucun défaut déclaré dans la description.");
  if (!repairs.descriptionKnown) reasons.push("Défauts inconnus : lance /analyse avec le texte complet de l'annonce.");

  return { score: clamp(Math.round(score), 0, 100), verdict, factors, risks, missing, reasons, budgetCategory };
}
