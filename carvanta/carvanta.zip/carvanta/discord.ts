// Client Discord minimal sans dépendance : API REST v10 + passerelle WebSocket (WebSocket natif de Node ≥ 22).
// Intent unique : GUILDS (aucun intent privilégié). Le token n'est jamais affiché dans les logs.

const API = "https://discord.com/api/v10";
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

export interface Interaction {
  id: string; token: string; type: number; application_id: string; channel_id?: string; guild_id?: string;
  data?: { name?: string; custom_id?: string; options?: { name: string; value: string | number | boolean }[] };
  member?: { permissions?: string; user?: { id: string; username: string } };
  user?: { id: string; username: string };
}

export class DiscordRest {
  constructor(private token: string, readonly appId: string) {}

  async call<T = unknown>(method: string, path: string, body?: unknown, retry = 0): Promise<T> {
    const r = await fetch(API + path, {
      method,
      headers: { authorization: `Bot ${this.token}`, "content-type": "application/json", "user-agent": "CarvantaScanner (local, 1.0)" },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    if (r.status === 429 && retry < 4) {
      const j = (await r.json().catch(() => ({}))) as { retry_after?: number };
      await sleep((j.retry_after ?? 1) * 1000 + 250);
      return this.call(method, path, body, retry + 1);
    }
    if (r.status >= 500 && retry < 3) { await sleep(1000 * (retry + 1)); return this.call(method, path, body, retry + 1); }
    if (!r.ok) {
      const txt = (await r.text()).slice(0, 300);
      throw new Error(`Discord ${method} ${path.replace(/\/[\w-]{60,}/g, "/…")} → HTTP ${r.status} ${txt}`);
    }
    return (r.status === 204 ? undefined : await r.json()) as T;
  }

  registerGuildCommands(guildId: string, commands: unknown[]) {
    return this.call("PUT", `/applications/${this.appId}/guilds/${guildId}/commands`, commands);
  }
  sendMessage(channelId: string, body: unknown) { return this.call("POST", `/channels/${channelId}/messages`, body); }
  respond(i: Interaction, type: number, data?: unknown) { return this.call("POST", `/interactions/${i.id}/${i.token}/callback`, { type, data }); }
  editOriginal(i: Interaction, data: unknown) { return this.call("PATCH", `/webhooks/${this.appId}/${i.token}/messages/@original`, data); }
  followUp(i: Interaction, data: unknown) { return this.call("POST", `/webhooks/${this.appId}/${i.token}`, data); }
}

type Handler = (i: Interaction) => Promise<void>;

/** Connexion passerelle avec heartbeat, reprise de session et reconnexion progressive. */
export class Gateway {
  private ws?: WebSocket;
  private seq: number | null = null;
  private sessionId?: string;
  private resumeUrl?: string;
  private hb?: ReturnType<typeof setInterval>;
  private acked = true;
  private attempts = 0;
  ready = false;
  user?: { id: string; username: string };

  constructor(private token: string, private onInteraction: Handler, private log: (m: string) => void) {}

  async start() {
    const url = this.resumeUrl ?? ((await fetch(`${API}/gateway`).then((r) => r.json())) as { url: string }).url;
    this.open(url);
  }

  private open(base: string) {
    const ws = new WebSocket(`${base}/?v=10&encoding=json`);
    this.ws = ws;
    ws.onmessage = (ev) => this.onMessage(JSON.parse(String(ev.data)));
    ws.onclose = (ev) => this.onClose(ev.code);
    ws.onerror = () => { /* onclose suit */ };
  }

  private send(op: number, d: unknown) { if (this.ws?.readyState === WebSocket.OPEN) this.ws.send(JSON.stringify({ op, d })); }

  private onMessage(p: { op: number; d: any; s: number | null; t: string | null }) {
    if (p.s !== null && p.s !== undefined) this.seq = p.s;
    switch (p.op) {
      case 10: { // HELLO
        const every = p.d.heartbeat_interval as number;
        clearInterval(this.hb);
        this.acked = true;
        setTimeout(() => this.send(1, this.seq), Math.random() * every);
        this.hb = setInterval(() => {
          if (!this.acked) { this.log("Passerelle : heartbeat sans réponse, reconnexion"); this.ws?.close(4000); return; }
          this.acked = false;
          this.send(1, this.seq);
        }, every);
        if (this.sessionId && this.resumeUrl) this.send(6, { token: this.token, session_id: this.sessionId, seq: this.seq });
        else this.send(2, { token: this.token, intents: 1, properties: { os: "android", browser: "carvanta", device: "carvanta" } });
        break;
      }
      case 11: this.acked = true; break;
      case 1: this.send(1, this.seq); break;
      case 7: this.ws?.close(4000); break; // reconnexion demandée
      case 9: // session invalide
        if (!p.d) { this.sessionId = undefined; this.resumeUrl = undefined; this.seq = null; }
        setTimeout(() => this.ws?.close(4000), 1000 + Math.random() * 4000);
        break;
      case 0:
        if (p.t === "READY") {
          this.sessionId = p.d.session_id; this.resumeUrl = p.d.resume_gateway_url; this.user = p.d.user;
          this.ready = true; this.attempts = 0;
          this.log(`Connecté à Discord en tant que ${p.d.user.username}`);
        } else if (p.t === "RESUMED") { this.ready = true; this.attempts = 0; this.log("Session Discord reprise"); }
        else if (p.t === "INTERACTION_CREATE") this.onInteraction(p.d).catch((e) => this.log(`Interaction : ${(e as Error).message}`));
        break;
    }
  }

  private onClose(code: number) {
    clearInterval(this.hb);
    this.ready = false;
    if ([4004, 4010, 4011, 4012, 4013, 4014].includes(code)) {
      this.log(`Passerelle fermée définitivement (code ${code}) : ${code === 4004 ? "token Discord invalide" : "configuration refusée"}`);
      process.exitCode = 1;
      return;
    }
    if ([4007, 4009].includes(code)) { this.sessionId = undefined; this.resumeUrl = undefined; this.seq = null; }
    const wait = Math.min(60_000, 1000 * 2 ** this.attempts++) + Math.random() * 1000;
    this.log(`Passerelle fermée (code ${code}), reconnexion dans ${Math.round(wait / 1000)} s`);
    setTimeout(() => this.start().catch((e) => {
      this.log(`Reconnexion : ${(e as Error).message}`);
      this.onClose(1006); // nouvel essai, délai croissant
    }), wait);
  }
}
