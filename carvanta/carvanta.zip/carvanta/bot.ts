// 🚗 Carvanta Scanner — bot Discord. Lancement : npx tsx carvanta/bot.ts
import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";
import { HERE, loadConfig, saveConfig, type Config } from "./config.ts";
import { DiscordRest, Gateway, type Interaction } from "./discord.ts";
import { alertButtons, alertEmbed, detailText, eur } from "./embed.ts";
import type { ImapConfig } from "./imap.ts";
import { VERDICT_RANK } from "./score.ts";
import { Carvanta } from "./service.ts";
import { Store } from "./store.ts";
import type { Analysis } from "./types.ts";

// ---------- .env (sans dépendance) ----------
export function loadEnv(path = join(HERE, ".env")) {
  if (!existsSync(path)) return;
  for (const raw of readFileSync(path, "utf8").split(/\r?\n/)) {
    const m = raw.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (m && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "").trim();
  }
}

const log = (m: string) => console.log(`[${new Date().toLocaleTimeString("fr-FR", { timeZone: "Europe/Paris" })}] ${m}`);

// ---------- Commandes ----------
const ADMIN_PERM = String(1 << 5); // MANAGE_GUILD
const S = 3, INT = 4, NUM = 10;
export const COMMANDS = [
  { name: "analyse", description: "Analyser une annonce : colle le texte complet de l'annonce Leboncoin", options: [
    { type: S, name: "texte", description: "Texte de l'annonce (titre, prix, critères, description)", required: true, max_length: 6000 },
    { type: S, name: "lien", description: "Lien de l'annonce (facultatif)" },
    { type: NUM, name: "cote", description: "Cote / prix de marché que tu as vérifié toi-même (facultatif)", min_value: 100 },
  ] },
  { name: "scan", description: "Relever maintenant les alertes e-mail Leboncoin" },
  { name: "opportunites", description: "Les meilleures annonces connues" },
  { name: "favori", description: "Ajouter / retirer une annonce des favoris", options: [{ type: S, name: "id", description: "Identifiant (ex. lbc:2845123456)", required: true }] },
  { name: "historique", description: "Les dernières alertes envoyées" },
  { name: "status", description: "État réel du service" },
  { name: "budget", description: "Modifier la fourchette de prix d'achat (admin)", default_member_permissions: ADMIN_PERM, options: [
    { type: INT, name: "min", description: "Prix minimum (€)", required: true, min_value: 0 },
    { type: INT, name: "max", description: "Prix maximum (€)", required: true, min_value: 1 },
  ] },
  { name: "region", description: "Départements surveillés, ex. 34,30,13 (vide = toute la France) (admin)", default_member_permissions: ADMIN_PERM, options: [
    { type: S, name: "departements", description: "Codes séparés par des virgules, ou « tous »", required: true },
  ] },
  { name: "config", description: "Lire ou modifier un réglage (admin)", default_member_permissions: ADMIN_PERM, options: [
    { type: S, name: "cle", description: "ex. filters.kmMax, costs.registration, opportunities.alertMinVerdict", required: true },
    { type: S, name: "valeur", description: "Nouvelle valeur (vide = afficher la valeur actuelle)" },
  ] },
];

/** Discord limite à 6 000 caractères l'ensemble des embeds d'un message. */
export function fitEmbeds(embeds: ReturnType<typeof alertEmbed>[], limit = 5800) {
  const size = (e: ReturnType<typeof alertEmbed>) => (e.title?.length ?? 0) + (e.description?.length ?? 0) + (e.footer?.text.length ?? 0) + e.fields.reduce((s, f) => s + f.name.length + f.value.length, 0);
  const out: typeof embeds = [];
  let total = 0;
  for (const e of embeds.slice(0, 10)) { if (total + size(e) > limit) break; out.push(e); total += size(e); }
  return out;
}

const opt = (i: Interaction, name: string) => i.data?.options?.find((o) => o.name === name)?.value;
const EPHEMERAL = 64;

function isAdmin(i: Interaction): boolean {
  const ids = (process.env.ADMIN_USER_IDS ?? "").split(",").map((s) => s.trim()).filter(Boolean);
  const uid = i.member?.user?.id ?? i.user?.id ?? "";
  if (ids.includes(uid)) return true;
  const perms = BigInt(i.member?.permissions ?? "0");
  return (perms & (1n << 5n)) !== 0n || (perms & (1n << 3n)) !== 0n; // MANAGE_GUILD ou ADMINISTRATOR
}

/** Modifie une clé de config en respectant le type existant (nombre, booléen, liste, texte). */
export function setConfigValue(cfg: Config, key: string, value: string): string {
  const parts = key.split(".");
  let node: any = cfg;
  for (const p of parts.slice(0, -1)) { if (!(p in node) || typeof node[p] !== "object") throw new Error(`clé inconnue : ${key}`); node = node[p]; }
  const last = parts.at(-1)!;
  if (!(last in node) || (typeof node[last] === "object" && node[last] !== null && !Array.isArray(node[last]))) throw new Error(`clé inconnue : ${key}`);
  const cur = node[last];
  let v: unknown;
  if (Array.isArray(cur)) v = value.trim() ? value.split(",").map((s) => s.trim()).filter(Boolean) : [];
  else if (typeof cur === "boolean") { if (!/^(true|false|oui|non)$/i.test(value)) throw new Error("valeur attendue : oui / non"); v = /^(true|oui)$/i.test(value); }
  else if (typeof cur === "number" || cur === null) {
    if (/^(null|aucun|vide)$/i.test(value)) v = null;
    else { const n = Number(value.replace(",", ".")); if (!Number.isFinite(n)) throw new Error("valeur numérique attendue"); v = n; }
  } else if (key === "opportunities.alertMinVerdict") {
    if (!(value in VERDICT_RANK)) throw new Error(`valeurs possibles : ${Object.keys(VERDICT_RANK).join(" / ")}`);
    v = value;
  } else v = value;
  node[last] = v;
  return JSON.stringify(v);
}

// ---------- Démarrage ----------
async function main() {
  loadEnv();
  const token = process.env.DISCORD_TOKEN;
  const appId = process.env.DISCORD_APP_ID;
  const guildId = process.env.DISCORD_GUILD_ID;
  if (!token || !appId || !guildId) {
    console.error("❌ Il manque DISCORD_TOKEN, DISCORD_APP_ID ou DISCORD_GUILD_ID dans carvanta/.env (voir .env.example).");
    process.exit(1);
  }
  let cfg = loadConfig();
  const store = new Store();
  store.meta.startedAt = new Date().toISOString();
  const app = new Carvanta(cfg, store, log);
  const rest = new DiscordRest(token, appId);
  const alertChannel = () => process.env.DISCORD_ALERT_CHANNEL_ID || cfg.discord.alertChannelId;
  const adminChannel = () => process.env.DISCORD_ADMIN_CHANNEL_ID || cfg.discord.adminChannelId || alertChannel();

  const imap: ImapConfig | undefined = process.env.IMAP_HOST && process.env.IMAP_USER && process.env.IMAP_PASSWORD ? {
    host: process.env.IMAP_HOST, port: Number(process.env.IMAP_PORT ?? 993), user: process.env.IMAP_USER,
    password: process.env.IMAP_PASSWORD, folder: process.env.IMAP_FOLDER ?? "INBOX", from: process.env.IMAP_FROM ?? "leboncoin",
  } : undefined;

  const sendAlert = async (a: Analysis) => {
    const ch = alertChannel();
    if (!ch) { log("⚠️ Aucun salon d'alerte configuré (DISCORD_ALERT_CHANNEL_ID)"); return; }
    await rest.sendMessage(ch, { embeds: [alertEmbed(a)], components: alertButtons(a) });
    store.markAlerted(a);
  };

  let polling = false;
  const poll = async (): Promise<string> => {
    if (!imap) return "Collecte e-mail non configurée (IMAP_HOST, IMAP_USER, IMAP_PASSWORD dans .env). Utilise /analyse en attendant.";
    if (polling) return "Une collecte est déjà en cours.";
    polling = true;
    try {
      const rep = await app.pollEmail(imap);
      for (const a of rep.alerts) { await sendAlert(a); await new Promise((r) => setTimeout(r, 800)); }
      store.save();
      return `📬 ${rep.seen} annonce(s) lue(s) · ${rep.created} nouvelle(s) · ${rep.duplicates} doublon(s) · ${rep.priceDrops} baisse(s) de prix · ${rep.alerts.length} alerte(s) envoyée(s)`;
    } catch (e) {
      const msg = (e as Error).message;
      log(`❌ Collecte e-mail : ${msg}`);
      if (store.meta.consecutiveErrors >= 3 && !store.meta.adminAlerted) {
        store.meta.adminAlerted = true;
        store.save();
        const ch = adminChannel();
        if (ch) await rest.sendMessage(ch, { content: `🚨 **Carvanta** : la collecte e-mail échoue depuis ${store.meta.consecutiveErrors} essais.\nDernière erreur : \`${msg.slice(0, 300)}\`` }).catch(() => {});
      }
      return `❌ Collecte impossible : ${msg.slice(0, 300)}`;
    } finally { polling = false; }
  };

  const reply = (i: Interaction, data: Record<string, unknown>, ephemeral = false) =>
    rest.respond(i, 4, ephemeral ? { ...data, flags: EPHEMERAL } : data);

  const onInteraction = async (i: Interaction): Promise<unknown> => {
    // ----- Boutons -----
    if (i.type === 3 && i.data?.custom_id?.startsWith("cv:")) {
      const [, action, ...rest_] = i.data.custom_id.split(":");
      const id = rest_.join(":");
      const s = store.get(id);
      if (!s) return reply(i, { content: "Annonce inconnue (base réinitialisée ?)." }, true);
      if (action === "detail") return reply(i, { content: s.lastAnalysis ? detailText(s.lastAnalysis) : "Pas encore analysée." }, true);
      if (action === "seen") { store.setStatus(id, "examinee"); store.save(); return reply(i, { content: `✅ ${id} marquée comme examinée.` }, true); }
      if (action === "fav") { const t = store.toggleFavorite(id); store.save(); return reply(i, { content: t?.favorite ? `★ ${id} ajoutée aux favoris.` : `☆ ${id} retirée des favoris.` }, true); }
      return;
    }
    if (i.type !== 2) return;
    const name = i.data?.name;
    const admin = ["budget", "region", "config"].includes(name ?? "");
    if (admin && !isAdmin(i)) return reply(i, { content: "⛔ Commande réservée aux administrateurs." }, true);

    switch (name) {
      case "analyse": {
        const text = String(opt(i, "texte") ?? "");
        if (text.trim().length < 15) return reply(i, { content: "Colle le texte complet de l'annonce (titre, prix, kilométrage, description)." }, true);
        const lien = opt(i, "lien") ? String(opt(i, "lien")) : undefined;
        if (lien && !/^https:\/\/(www\.)?leboncoin\.fr\//.test(lien)) return reply(i, { content: "Le lien doit être une annonce https://www.leboncoin.fr/…" }, true);
        const cote = opt(i, "cote") ? Number(opt(i, "cote")) : undefined;
        const a = app.analyseText(text, lien, cote);
        return reply(i, { embeds: [alertEmbed(a)], components: alertButtons(a) });
      }
      case "scan": {
        await rest.respond(i, 5, { flags: EPHEMERAL });
        const msg = await poll();
        return void (await rest.editOriginal(i, { content: msg }));
      }
      case "opportunites": {
        const best = store.best(5);
        if (!best.length) return reply(i, { content: "Aucune annonce analysée pour l'instant." }, true);
        return reply(i, { content: "🏆 Meilleures annonces connues (disponibilité non revérifiée) :", embeds: fitEmbeds(best.map((s) => alertEmbed(s.lastAnalysis!))) });
      }
      case "favori": {
        const id = String(opt(i, "id") ?? "").trim();
        const t = store.toggleFavorite(id);
        store.save();
        return reply(i, { content: t ? (t.favorite ? `★ ${t.listing.id} ajoutée aux favoris.` : `☆ ${t.listing.id} retirée des favoris.`) : "Identifiant inconnu." }, true);
      }
      case "historique": {
        const h = store.alerts(10);
        const favs = store.all().filter((s) => s.favorite).slice(0, 10);
        const lines = h.map((x) => `• ${new Date(x.date).toLocaleString("fr-FR", { timeZone: "Europe/Paris" })} — ${x.id} — ${eur(x.price)} — ${x.verdict} (${x.score}/100)`);
        const fl = favs.map((s) => `★ ${s.listing.id} — ${s.listing.title.slice(0, 60)} — ${eur(s.listing.price)}`);
        return reply(i, { content: [`**Dernières alertes**`, ...(lines.length ? lines : ["aucune"]), "", `**Favoris**`, ...(fl.length ? fl : ["aucun"])].join("\n").slice(0, 2000) }, true);
      }
      case "status": {
        const m = store.meta;
        const all = store.all();
        const fmt = (d?: string) => (d ? new Date(d).toLocaleString("fr-FR", { timeZone: "Europe/Paris" }) : "jamais");
        return reply(i, { content: [
          "**Carvanta Scanner — état**",
          `Discord : ${gw.ready ? "connecté" : "reconnexion en cours"}`,
          `Collecte e-mail : ${imap ? `configurée (${imap.host})` : "non configurée"}`,
          `Dernière collecte : ${fmt(m.lastPollAt)} · dernière réussie : ${fmt(m.lastPollOk)}`,
          `Erreurs consécutives : ${m.consecutiveErrors}${m.lastError ? ` · dernière : ${m.lastError.slice(0, 150)}` : ""}`,
          `Annonces en base : ${all.length} · analysées : ${all.filter((s) => s.lastAnalysis).length} · alertes envoyées : ${store.alerts(100000).length}`,
          `Budget : ${eur(cfg.budget.min)} – ${eur(cfg.budget.max)} · zone : ${cfg.filters.departments.join(", ") || "toute la France"}`,
          `Démarré : ${fmt(m.startedAt)}`,
        ].join("\n") }, true);
      }
      case "budget": {
        const min = Number(opt(i, "min")), max = Number(opt(i, "max"));
        if (!(max > min)) return reply(i, { content: "Le maximum doit être supérieur au minimum." }, true);
        cfg.budget = { min, max }; saveConfig(cfg); app.cfg = cfg;
        return reply(i, { content: `💶 Budget : ${eur(min)} – ${eur(max)}` }, true);
      }
      case "region": {
        const raw = String(opt(i, "departements") ?? "");
        const deps = /^tous$/i.test(raw.trim()) ? [] : raw.split(/[,\s]+/).map((s) => s.trim().toUpperCase()).filter(Boolean);
        if (deps.some((d) => !/^(\d{2}|2A|2B|97\d)$/.test(d))) return reply(i, { content: "Format : 34,30,13 (ou « tous »)." }, true);
        cfg.filters.departments = deps; saveConfig(cfg); app.cfg = cfg;
        return reply(i, { content: `📍 Zone : ${deps.join(", ") || "toute la France"}` }, true);
      }
      case "config": {
        const key = String(opt(i, "cle") ?? "");
        const val = opt(i, "valeur");
        if (val === undefined) {
          const cur = key.split(".").reduce<any>((n, k) => (n == null ? undefined : n[k]), cfg);
          return reply(i, { content: cur === undefined ? `Clé inconnue : ${key}` : `\`${key}\` = \`${JSON.stringify(cur)}\`` }, true);
        }
        try {
          const next = structuredClone(cfg);
          const shown = setConfigValue(next, key, String(val));
          saveConfig(next); cfg = next; app.cfg = cfg;
          return reply(i, { content: `⚙️ \`${key}\` = \`${shown}\`` }, true);
        } catch (e) { return reply(i, { content: `❌ ${(e as Error).message}` }, true); }
      }
    }
  };

  const gw: Gateway = new Gateway(token, (i: Interaction): Promise<void> => onInteraction(i).then(() => undefined).catch(async (e: unknown) => {
    log(`Commande « ${i.data?.name ?? i.data?.custom_id} » : ${(e as Error).message}`);
    await rest.respond(i, 4, { content: "❌ Erreur interne, réessaie.", flags: EPHEMERAL }).catch(() => {});
  }), log);

  await rest.registerGuildCommands(guildId, COMMANDS);
  log(`✅ ${COMMANDS.length} commandes enregistrées sur le serveur`);
  await gw.start();

  const ch = alertChannel();
  if (ch) await rest.sendMessage(ch, { embeds: [{ title: "🚗 Carvanta Scanner en ligne", color: 0x7c3aed,
    description: `Budget ${eur(cfg.budget.min)} – ${eur(cfg.budget.max)} · zone ${cfg.filters.departments.join(", ") || "France"}\nCollecte e-mail : ${imap ? `toutes les ${cfg.polling.everyMinutes} min` : "non configurée (utilise /analyse)"}` }] })
    .catch((e) => log(`Salon d'alerte : ${(e as Error).message}`));

  if (imap) {
    const loop = async () => {
      await poll().then(log);
      setTimeout(loop, cfg.polling.everyMinutes * 60_000);
    };
    setTimeout(loop, 5_000);
  }
  const bye = () => { store.save(); log("Arrêt propre, base sauvegardée."); process.exit(0); };
  process.on("SIGINT", bye);
  process.on("SIGTERM", bye);
}

if (process.argv[1]?.endsWith("bot.ts")) main().catch((e) => { console.error("❌", (e as Error).message); process.exit(1); });
